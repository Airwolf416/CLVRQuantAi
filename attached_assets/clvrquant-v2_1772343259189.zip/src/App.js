// ─────────────────────────────────────────────────────────
// CLVRQuant v2
// NEW: Macro countdown timers · Volume spike detector
//      Funding rate flip alerts · Liquidation heatmap
//      Push notifications · In-app alert banners
// ─────────────────────────────────────────────────────────
const FINNHUB_KEY     = "YOUR_FINNHUB_KEY_HERE";
const ANTHROPIC_KEY   = "YOUR_ANTHROPIC_KEY_HERE";
const GAS_WEBHOOK_URL = "YOUR_GOOGLE_APPS_SCRIPT_WEBHOOK_URL";

import { useState, useEffect, useRef, useCallback } from "react";

const C = {
  bg:"#050709",navy:"#080d18",panel:"#0c1220",border:"#141e35",border2:"#1c2b4a",
  gold:"#c9a84c",gold2:"#e8c96d",gold3:"#f7e0a0",text:"#c8d4ee",muted:"#4a5d80",muted2:"#6b7fa8",white:"#f0f4ff",
  green:"#00c787",red:"#ff4060",orange:"#ff8c00",cyan:"#00d4ff",blue:"#3b82f6",teal:"#14b8a6",purple:"#a855f7",pink:"#ec4899",
  navBg:"#050709",navBorder:"#141e35",inputBg:"#080d18",
};
const SERIF="'Playfair Display',Georgia,serif";
const MONO="'IBM Plex Mono',monospace";
const SANS="'Barlow',system-ui,sans-serif";

const pct=(v,d=2)=>{const n=Number(v);if(isNaN(n))return"—";return(n>=0?"+":"")+n.toFixed(d)+"%";};
const fmt=(p,sym)=>{
  if(!p&&p!==0)return"—";p=Number(p);if(isNaN(p)||p===0)return"—";
  if(["EURUSD","GBPUSD","AUDUSD","USDCHF"].includes(sym))return p.toFixed(4);
  if(["USDJPY","USDCAD"].includes(sym))return p.toFixed(2);
  if(sym==="XAG")return"$"+p.toFixed(2);if(sym==="XAU")return"$"+p.toFixed(0);
  if(p>=1000)return"$"+p.toFixed(0);if(p>=100)return"$"+p.toFixed(1);
  if(p>=1)return"$"+p.toFixed(2);return"$"+p.toFixed(6);
};
const rndInt=(a,b)=>Math.floor(a+Math.random()*(b-a+1));

const CRYPTO_BASE={BTC:84000,ETH:1590,SOL:130,WIF:0.82,DOGE:0.168,AVAX:20.1,LINK:12.8,ARB:0.38,PEPE:0.0000072};
const EQUITY_BASE={TSLA:248,NVDA:103,AAPL:209,GOOGL:155,META:558,MSFT:388,AMZN:192,MSTR:310};
const METALS_BASE={XAU:3285,XAG:32.8};
const FOREX_BASE={EURUSD:1.0842,GBPUSD:1.2715,USDJPY:149.82,USDCHF:0.9012,AUDUSD:0.6524,USDCAD:1.3654};
const CRYPTO_SYMS=Object.keys(CRYPTO_BASE);
const EQUITY_SYMS=Object.keys(EQUITY_BASE);
const METALS_SYMS=Object.keys(METALS_BASE);
const FOREX_SYMS=Object.keys(FOREX_BASE);
const FH_METALS={XAU:"OANDA:XAU_USD",XAG:"OANDA:XAG_USD"};
const FH_FOREX={EURUSD:"OANDA:EUR_USD",GBPUSD:"OANDA:GBP_USD",USDJPY:"OANDA:USD_JPY",USDCHF:"OANDA:USD_CHF",AUDUSD:"OANDA:AUD_USD",USDCAD:"OANDA:USD_CAD"};

// ─── MACRO EVENTS with ET times for live countdown ───────
const MACRO_EVENTS=[
  {id:1,bank:"FED",flag:"🇺🇸",name:"FOMC Rate Decision",date:"2025-03-19",timeET:"14:00",current:"4.25–4.50%",forecast:"Hold",impact:"HIGH",desc:"Fed decision. Watch dot plot & Powell presser. Markets pricing <5% cut chance.",currency:"USD",assets:["BTC","ETH","XAU","EURUSD","USDJPY"],expectedMove:3.5},
  {id:2,bank:"FED",flag:"🇺🇸",name:"FOMC Rate Decision",date:"2025-05-07",timeET:"14:00",current:"4.25–4.50%",forecast:"Hold",impact:"HIGH",desc:"Second FOMC 2025. First cut possible if inflation cools.",currency:"USD",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:3.0},
  {id:3,bank:"FED",flag:"🇺🇸",name:"FOMC Rate Decision",date:"2025-06-18",timeET:"14:00",current:"4.25–4.50%",forecast:"–25bp",impact:"HIGH",desc:"June FOMC — first 25bp cut possible. Major USD mover.",currency:"USD",assets:["BTC","ETH","XAU","EURUSD","USDJPY"],expectedMove:4.5},
  {id:4,bank:"ECB",flag:"🇪🇺",name:"ECB Rate Decision",date:"2025-03-06",timeET:"09:15",current:"3.15%",forecast:"–25bp",impact:"HIGH",desc:"ECB cut 25bp expected. Lagarde presser key for EUR/USD.",currency:"EUR",assets:["EURUSD","GBPUSD","XAU"],expectedMove:2.5},
  {id:5,bank:"ECB",flag:"🇪🇺",name:"ECB Rate Decision",date:"2025-04-17",timeET:"09:15",current:"2.90%",forecast:"–25bp",impact:"HIGH",desc:"Second ECB cut.",currency:"EUR",assets:["EURUSD","GBPUSD"],expectedMove:2.0},
  {id:6,bank:"BOJ",flag:"🇯🇵",name:"BOJ Rate Decision",date:"2025-03-19",timeET:"02:00",current:"0.50%",forecast:"Hold",impact:"HIGH",desc:"BOJ on hold. Hawkish surprise = JPY rally 200–300 pips.",currency:"JPY",assets:["USDJPY","AUDUSD"],expectedMove:2.0},
  {id:7,bank:"BOJ",flag:"🇯🇵",name:"BOJ Rate Decision",date:"2025-05-01",timeET:"02:00",current:"0.50%",forecast:"+25bp",impact:"HIGH",desc:"BOJ may hike again. USD/JPY extremely sensitive.",currency:"JPY",assets:["USDJPY"],expectedMove:3.0},
  {id:8,bank:"BOC",flag:"🇨🇦",name:"BOC Rate Decision",date:"2025-03-12",timeET:"09:45",current:"3.00%",forecast:"Hold",impact:"HIGH",desc:"BOC on hold after 2024 cuts. Oil key for CAD.",currency:"CAD",assets:["USDCAD"],expectedMove:1.5},
  {id:9,bank:"BOC",flag:"🇨🇦",name:"BOC Rate Decision",date:"2025-04-16",timeET:"09:45",current:"3.00%",forecast:"–25bp",impact:"HIGH",desc:"BOC may resume cutting.",currency:"CAD",assets:["USDCAD"],expectedMove:2.0},
  {id:10,bank:"BOE",flag:"🇬🇧",name:"BOE Rate Decision",date:"2025-03-20",timeET:"12:00",current:"4.50%",forecast:"Hold",impact:"HIGH",desc:"BOE holds. GBP/USD driven by BoE tone.",currency:"GBP",assets:["GBPUSD"],expectedMove:1.5},
  {id:11,bank:"US CPI",flag:"🇺🇸",name:"US CPI Inflation",date:"2025-03-12",timeET:"08:30",current:"3.0%",forecast:"2.9%",impact:"HIGH",desc:"Soft print = rate cut catalyst. BTC, gold, forex all move hard.",currency:"USD",assets:["BTC","ETH","XAU","EURUSD","USDJPY"],expectedMove:4.0},
  {id:12,bank:"US CPI",flag:"🇺🇸",name:"US CPI Inflation",date:"2025-04-10",timeET:"08:30",current:"—",forecast:"—",impact:"HIGH",desc:"April CPI. Key for June FOMC decision.",currency:"USD",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:4.0},
  {id:13,bank:"NFP",flag:"🇺🇸",name:"Non-Farm Payrolls",date:"2025-03-07",timeET:"08:30",current:"256K",forecast:"175K",impact:"HIGH",desc:"Weak NFP = dovish Fed = crypto/gold rally. Watch the number.",currency:"USD",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:3.5},
  {id:14,bank:"NFP",flag:"🇺🇸",name:"Non-Farm Payrolls",date:"2025-04-04",timeET:"08:30",current:"—",forecast:"—",impact:"HIGH",desc:"April NFP. Two weak prints = June cut locked in.",currency:"USD",assets:["BTC","ETH","XAU"],expectedMove:3.5},
  {id:15,bank:"PCE",flag:"🇺🇸",name:"US PCE Inflation",date:"2025-03-28",timeET:"08:30",current:"2.6%",forecast:"2.5%",impact:"HIGH",desc:"Fed's preferred gauge. Below 2.5% = cut signal. ETH pumped 3% on the Feb 28 print.",currency:"USD",assets:["BTC","ETH","SOL","XAU","EURUSD"],expectedMove:3.0},
  {id:16,bank:"PCE",flag:"🇺🇸",name:"US PCE Inflation",date:"2025-04-30",timeET:"08:30",current:"—",forecast:"—",impact:"HIGH",desc:"April PCE. Crucial for Fed rate path.",currency:"USD",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:3.0},
];

const SIGNALS_POOL=[
  {icon:"🚀",dir:"LONG",token:"SOL",conf:94,lev:"10x",src:"hyperliquid",desc:"Smart money wallets +$2.4M in 18min. Shorts clustered above — sweep incoming.",tags:[{l:"ON-CHAIN",c:"green"},{l:"LIQ SWEEP",c:"cyan"}]},
  {icon:"📉",dir:"SHORT",token:"BTC",conf:81,lev:"5x",src:"hyperliquid",desc:"OI at resistance. Funding extreme positive. Reversal setup forming.",tags:[{l:"FUNDING",c:"orange"},{l:"RESISTANCE",c:"red"}]},
  {icon:"🔥",dir:"LONG",token:"WIF",conf:88,lev:"3x",src:"hyperliquid",desc:"Whale 0x7f3 opened 8.4M WIF perp. Same wallet +340% on BONK pre-pump.",tags:[{l:"WHALE",c:"orange"},{l:"NEUTRAL FUND",c:"green"}]},
  {icon:"📈",dir:"LONG",token:"TSLA",conf:86,lev:"5x",src:"trade.xyz",desc:"Earnings beat whisper +18%. Smart money opened $3.1M long.",tags:[{l:"EARNINGS",c:"gold"},{l:"WHALE",c:"orange"}]},
  {icon:"🚀",dir:"LONG",token:"NVDA",conf:91,lev:"5x",src:"trade.xyz",desc:"H100 supply chain: +40% shipments detected in Taiwan customs.",tags:[{l:"SUPPLY CHAIN",c:"cyan"},{l:"NEG FUND",c:"green"}]},
  {icon:"🥇",dir:"LONG",token:"XAU",conf:89,lev:"5x",src:"phantom",desc:"Central bank gold buying +42t. DXY weakening. Path to $3,400 open.",tags:[{l:"MACRO",c:"gold"},{l:"CENTRAL BANK",c:"teal"}]},
  {icon:"💱",dir:"SHORT",token:"USDJPY",conf:84,lev:"10x",src:"phantom",desc:"BOJ hawkish minutes leaked. JPY intervention risk at ¥150.",tags:[{l:"BOJ",c:"teal"},{l:"INTERVENTION",c:"red"}]},
  {icon:"📊",dir:"LONG",token:"EURUSD",conf:79,lev:"10x",src:"phantom",desc:"ECB holds, Fed cutting. Rate differential narrowing.",tags:[{l:"RATE DIFF",c:"blue"},{l:"LIQ SWEEP",c:"green"}]},
  {icon:"💎",dir:"LONG",token:"PEPE",conf:76,lev:"5x",src:"hyperliquid",desc:"$18M PEPE exchange outflow. Supply squeeze. Funding negative.",tags:[{l:"OUTFLOW",c:"green"},{l:"NEG FUND",c:"cyan"}]},
  {icon:"⚠️",dir:"SHORT",token:"META",conf:73,lev:"3x",src:"trade.xyz",desc:"EU antitrust fine €1.2B imminent. Options flow bearish.",tags:[{l:"REGULATORY",c:"red"},{l:"FUNDING",c:"orange"}]},
];

function Sparkline({data,color,width=80,height=22}){
  if(!data||data.length<2)return<span style={{fontSize:8,opacity:.3,color:C.muted}}>—</span>;
  const min=Math.min(...data),max=Math.max(...data),range=max-min||1;
  const pts=data.map((v,i)=>`${(i/(data.length-1))*width},${height-((v-min)/range)*(height-2)+1}`).join(" ");
  const up=data[data.length-1]>=data[0];
  return(<svg width={width} height={height} style={{overflow:"visible",flexShrink:0}}><polyline points={pts} fill="none" stroke={color||(up?C.green:C.red)} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round"/><circle cx={(data.length-1)/(data.length-1)*width} cy={height-((data[data.length-1]-min)/range)*(height-2)+1} r="2.5" fill={color||(up?C.green:C.red)}/></svg>);
}

async function sendPush(title,body,tag="clvrquant"){
  if(!("Notification" in window))return;
  if(Notification.permission==="default")await Notification.requestPermission();
  if(Notification.permission==="granted"){try{new Notification(title,{body,tag});}catch(e){}}
}

function AlertBanner({alerts,onDismiss}){
  if(!alerts||alerts.length===0)return null;
  const a=alerts[0];
  const tc={macro:{bg:"rgba(255,140,0,.12)",border:"rgba(255,140,0,.35)",icon:"🏦",color:C.orange},volume:{bg:"rgba(0,212,255,.10)",border:"rgba(0,212,255,.35)",icon:"📊",color:C.cyan},funding:{bg:"rgba(0,199,135,.10)",border:"rgba(0,199,135,.35)",icon:"⚡",color:C.green},liq:{bg:"rgba(255,64,96,.10)",border:"rgba(255,64,96,.35)",icon:"💥",color:C.red},price:{bg:"rgba(201,168,76,.10)",border:"rgba(201,168,76,.35)",icon:"✦",color:C.gold}}[a.type]||{bg:"rgba(201,168,76,.10)",border:"rgba(201,168,76,.35)",icon:"✦",color:C.gold};
  return(<div style={{position:"fixed",top:0,left:0,right:0,zIndex:200,padding:"0 12px",maxWidth:640,margin:"0 auto"}}><div style={{background:tc.bg,border:`1px solid ${tc.border}`,borderTop:"none",borderRadius:"0 0 6px 6px",padding:"10px 14px",backdropFilter:"blur(16px)"}}><div style={{display:"flex",alignItems:"flex-start",gap:10}}><span style={{fontSize:16,flexShrink:0,marginTop:1}}>{tc.icon}</span><div style={{flex:1}}><div style={{fontFamily:MONO,fontSize:9,fontWeight:700,color:tc.color,letterSpacing:"0.18em",textTransform:"uppercase",marginBottom:3}}>{a.title}</div><div style={{fontFamily:SANS,fontSize:11,color:C.text,lineHeight:1.6}}>{a.body}</div>{a.assets&&<div style={{display:"flex",gap:4,marginTop:5,flexWrap:"wrap"}}>{a.assets.map(sym=><span key={sym} style={{fontFamily:MONO,fontSize:8,color:tc.color,background:tc.bg,border:`1px solid ${tc.border}`,borderRadius:2,padding:"1px 6px"}}>{sym}</span>)}</div>}</div><button onClick={()=>onDismiss(a.id)} style={{background:"none",border:"none",color:C.muted2,fontSize:18,cursor:"pointer",flexShrink:0,padding:0,lineHeight:1}}>×</button></div>{alerts.length>1&&<div style={{fontFamily:MONO,fontSize:7,color:C.muted,marginTop:6,letterSpacing:"0.15em"}}>{alerts.length-1} MORE ALERT{alerts.length>2?"S":""}</div>}</div></div>);
}

function Countdown({dateStr,timeET,compact=false}){
  const [diff,setDiff]=useState(null);
  useEffect(()=>{
    const calc=()=>{const[h,m]=timeET.split(":").map(Number);const[y,mo,d]=dateStr.split("-").map(Number);const target=new Date(Date.UTC(y,mo-1,d,h+5,m,0));setDiff(target-new Date());};
    calc();const iv=setInterval(calc,1000);return()=>clearInterval(iv);
  },[dateStr,timeET]);
  if(diff===null)return null;
  if(diff<0)return<span style={{fontFamily:MONO,fontSize:compact?7:8,color:C.muted}}>PAST</span>;
  const s=Math.floor(diff/1000);const dd=Math.floor(s/86400);const h=Math.floor((s%86400)/3600);const min=Math.floor((s%3600)/60);const sec=s%60;
  const isHot=diff<30*60*1000;const isWarm=diff<2*60*60*1000;const col=isHot?C.red:isWarm?C.orange:C.muted2;
  if(compact){const label=dd>0?`${dd}d ${h}h`:h>0?`${h}h ${min}m`:`${min}m ${sec}s`;return<span style={{fontFamily:MONO,fontSize:8,color:col,fontWeight:isHot?700:400}}>{label}</span>;}
  return(<div style={{display:"flex",gap:6,alignItems:"center"}}>
    {dd>0&&<div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{dd}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted,letterSpacing:"0.12em"}}>DAYS</div></div>}
    <div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{String(h).padStart(2,"0")}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted,letterSpacing:"0.12em"}}>HRS</div></div>
    <div style={{fontFamily:MONO,color:col,fontSize:16,marginBottom:10}}>:</div>
    <div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{String(min).padStart(2,"0")}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted,letterSpacing:"0.12em"}}>MIN</div></div>
    {dd===0&&<><div style={{fontFamily:MONO,color:col,fontSize:16,marginBottom:10}}>:</div><div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{String(sec).padStart(2,"0")}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted,letterSpacing:"0.12em"}}>SEC</div></div></>}
  </div>);
}

function LiqHeatmap({sym,price}){
  if(!price)return null;
  const step=sym==="BTC"?500:sym==="ETH"?50:sym==="SOL"?5:sym==="XAU"?20:null;
  if(!step)return null;
  const seed=Math.floor(price/step);
  const levels=[];
  for(let i=-6;i<=6;i++){if(i===0)continue;const lvl=(seed+i)*step;const dist=Math.abs(lvl-price)/price*100;const isRound=lvl%1000===0||lvl%500===0;const size=isRound?Math.floor(180+Math.random()*220):Math.floor(20+Math.random()*100);const side=i<0?"long":"short";if(dist>0.1&&dist<6)levels.push({price:lvl,size,side,dist});}
  levels.sort((a,b)=>a.price-b.price);
  const above=levels.filter(l=>l.price>price).slice(0,4).reverse();
  const below=levels.filter(l=>l.price<price).reverse().slice(0,4);
  const maxSize=Math.max(...levels.map(l=>l.size),1);
  return(<div>
    {above.reverse().map(l=>(<div key={l.price} style={{display:"flex",alignItems:"center",gap:6,marginBottom:3}}><div style={{fontFamily:MONO,fontSize:8,color:C.red,width:62,textAlign:"right"}}>{fmt(l.price,sym)}</div><div style={{flex:1,position:"relative",height:12,background:"rgba(255,64,96,.06)",borderRadius:1}}><div style={{position:"absolute",right:0,top:0,bottom:0,width:`${(l.size/maxSize)*100}%`,background:`rgba(255,64,96,${0.15+l.size/maxSize*0.45})`,borderRadius:1}}/></div><div style={{fontFamily:MONO,fontSize:7,color:C.muted2,width:38}}>${l.size}M</div></div>))}
    <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:3,marginTop:2}}><div style={{fontFamily:MONO,fontSize:9,color:C.gold,width:62,textAlign:"right",fontWeight:700}}>{fmt(price,sym)}</div><div style={{flex:1,height:1,background:`linear-gradient(90deg,${C.gold},transparent)`}}/><div style={{fontFamily:MONO,fontSize:7,color:C.gold,width:38}}>NOW</div></div>
    {below.map(l=>(<div key={l.price} style={{display:"flex",alignItems:"center",gap:6,marginBottom:3}}><div style={{fontFamily:MONO,fontSize:8,color:C.green,width:62,textAlign:"right"}}>{fmt(l.price,sym)}</div><div style={{flex:1,position:"relative",height:12,background:"rgba(0,199,135,.06)",borderRadius:1}}><div style={{position:"absolute",left:0,top:0,bottom:0,width:`${(l.size/maxSize)*100}%`,background:`rgba(0,199,135,${0.15+l.size/maxSize*0.45})`,borderRadius:1}}/></div><div style={{fontFamily:MONO,fontSize:7,color:C.muted2,width:38}}>${l.size}M</div></div>))}
    <div style={{display:"flex",justifyContent:"space-between",marginTop:8,paddingTop:6,borderTop:`1px solid ${C.border}`}}><div style={{fontFamily:MONO,fontSize:7,color:C.green}}>▲ GREEN = LONG LIQDS BELOW</div><div style={{fontFamily:MONO,fontSize:7,color:C.red}}>SHORT LIQDS ABOVE ▼</div></div>
  </div>);
}

function Toast({msg,onDone}){useEffect(()=>{const t=setTimeout(onDone,3500);return()=>clearTimeout(t);},[onDone]);return(<div style={{position:"fixed",bottom:88,left:"50%",transform:"translateX(-50%)",background:C.gold,color:C.bg,borderRadius:2,padding:"10px 20px",fontSize:10,fontWeight:700,fontFamily:MONO,zIndex:9999,letterSpacing:"0.1em",boxShadow:`0 4px 24px rgba(201,168,76,.5)`,whiteSpace:"nowrap"}}>{msg}</div>);}

async function fetchHyperliquid(){
  const[r1,r2]=await Promise.all([fetch("https://api.hyperliquid.xyz/info",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"allMids"})}),fetch("https://api.hyperliquid.xyz/info",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"metaAndAssetCtxs"})})]);
  const mids=await r1.json(),meta=await r2.json();
  const funding={};
  meta[0].universe.forEach((asset,i)=>{if(CRYPTO_SYMS.includes(asset.name))funding[asset.name]={funding:+(parseFloat(meta[1][i]?.funding||0)*100).toFixed(4),oi:parseFloat(meta[1][i]?.openInterest||0)*parseFloat(meta[1][i]?.markPx||0),volume:parseFloat(meta[1][i]?.dayNtlVlm||0)};});
  const result={};
  CRYPTO_SYMS.forEach(sym=>{if(mids[sym]){const price=parseFloat(mids[sym]);result[sym]={price,chg:+((price-CRYPTO_BASE[sym])/CRYPTO_BASE[sym]*100).toFixed(2),funding:funding[sym]?.funding||0,oi:funding[sym]?.oi||0,volume:funding[sym]?.volume||0,live:true};}});
  return result;
}
async function fhQuote(symbol){const r=await fetch(`https://finnhub.io/api/v1/quote?symbol=${symbol}&token=${FINNHUB_KEY}`);if(!r.ok)throw new Error(`FH ${r.status}`);const d=await r.json();if(!d||!d.c||d.c===0)throw new Error("zero");return{price:d.c,chg:d.dp??(d.pc?(d.c-d.pc)/d.pc*100:0),live:true};}
async function fetchFinnhub(){
  const stocks={},metals={},forex={};
  await Promise.allSettled([...EQUITY_SYMS.map(async sym=>{try{stocks[sym]=await fhQuote(sym);}catch{stocks[sym]={price:EQUITY_BASE[sym],chg:0,live:false};}}), ...Object.entries(FH_METALS).map(async([sym,fh])=>{try{metals[sym]=await fhQuote(fh);}catch{metals[sym]={price:METALS_BASE[sym],chg:0,live:false};}}), ...Object.entries(FH_FOREX).map(async([sym,fh])=>{try{forex[sym]=await fhQuote(fh);}catch{forex[sym]={price:FOREX_BASE[sym],chg:0,live:false};}})]);
  return{stocks,metals,forex};
}

export default function App(){
  const[tab,setTab]=useState("radar");
  const[priceTab,setPriceTab]=useState("crypto");
  const[sigSubTab,setSigSubTab]=useState("all");
  const[macroFilter,setMacroFilter]=useState("ALL");
  const[liqSym,setLiqSym]=useState("BTC");
  const[notifPerm,setNotifPerm]=useState(typeof Notification!=="undefined"?Notification.permission:"default");
  const[cryptoPrices,setCryptoPrices]=useState(()=>Object.fromEntries(CRYPTO_SYMS.map(k=>[k,{price:CRYPTO_BASE[k],chg:0,funding:0,oi:0,volume:0,live:false,oiHistory:[],volHistory:[],fundHistory:[]}])));
  const[equityPrices,setEquityPrices]=useState(()=>Object.fromEntries(EQUITY_SYMS.map(k=>[k,{price:EQUITY_BASE[k],chg:0,live:false}])));
  const[metalPrices,setMetalPrices]=useState(()=>Object.fromEntries(METALS_SYMS.map(k=>[k,{price:METALS_BASE[k],chg:0,live:false}])));
  const[forexPrices,setForexPrices]=useState(()=>Object.fromEntries(FOREX_SYMS.map(k=>[k,{price:FOREX_BASE[k],chg:0,live:false}])));
  const[flashes,setFlashes]=useState({});
  const prevRef=useRef({});
  const volRef=useRef({});
  const fundRef=useRef({});
  const[watchlist,setWatchlist]=useState(["BTC","ETH","SOL","XAU","TSLA"]);
  const[signals,setSignals]=useState(SIGNALS_POOL.slice(0,8).map((s,i)=>({...s,time:`${i*4+2}m ago`,id:i})));
  const[flashSigId,setFlashSigId]=useState(null);
  const[sigCount,setSigCount]=useState(44);
  const[tick,setTick]=useState(0);
  const[lastUpdate,setLastUpdate]=useState(new Date());
  const[hlStatus,setHlStatus]=useState("connecting");
  const[fhStatus,setFhStatus]=useState("connecting");
  const[toast,setToast]=useState(null);
  const[aiInput,setAiInput]=useState("");
  const[aiOutput,setAiOutput]=useState("");
  const[aiLoading,setAiLoading]=useState(false);
  const idRef=useRef(300);
  const firedAlerts=useRef(new Set());
  const macroFired=useRef(new Set());
  const[activeAlerts,setActiveAlerts]=useState([]);
  const[subEmail,setSubEmail]=useState("");
  const[subName,setSubName]=useState("");
  const[subLoading,setSubLoading]=useState(false);
  const[subList,setSubList]=useState([]);
  const[briefLoading,setBriefLoading]=useState(false);
  const[briefData,setBriefData]=useState(null);
  const[briefDate,setBriefDate]=useState(null);

  const addAlert=useCallback((alert)=>{
    const key=alert.id||alert.title+Date.now();
    const dedupeKey=alert.id||alert.title;
    if(firedAlerts.current.has(dedupeKey))return;
    firedAlerts.current.add(dedupeKey);
    setActiveAlerts(prev=>[{...alert,id:key,ts:Date.now()},...prev.slice(0,4)]);
    sendPush(alert.title,alert.body,dedupeKey);
    setToast(`🔔 ${alert.title}`);
  },[]);
  const dismissAlert=(id)=>setActiveAlerts(prev=>prev.filter(a=>a.id!==id));

  const triggerFlashes=useCallback((updates)=>{
    const nF={};
    Object.entries(updates).forEach(([sym,d])=>{const prev=prevRef.current[sym];if(prev&&d.price&&d.price!==prev)nF[sym]=d.price>prev?"green":"red";if(d.price)prevRef.current[sym]=d.price;});
    if(Object.keys(nF).length){setFlashes(f=>({...f,...nF}));setTimeout(()=>setFlashes(f=>{const n={...f};Object.keys(nF).forEach(k=>delete n[k]);return n;}),700);}
  },[]);

  const checkVolumeSpike=useCallback((sym,vol)=>{
    const hist=volRef.current[sym]||[];
    if(hist.length>=5){const avg=hist.slice(-5).reduce((a,b)=>a+b,0)/5;if(avg>0&&vol>avg*5){addAlert({type:"volume",title:`VOLUME SPIKE · ${sym}`,body:`${sym} volume is ${(vol/avg).toFixed(1)}× the 5-period average. Historically precedes a 2–4% move. Macro event or whale accumulation detected.`,assets:[sym],id:`vol-${sym}-${Math.floor(Date.now()/300000)}`});}}
    volRef.current[sym]=[...hist,vol].slice(-20);
  },[addAlert]);

  const checkFundingFlip=useCallback((sym,f)=>{
    const hist=fundRef.current[sym]||[];
    if(hist.length>=3){
      const p3=hist.slice(-3);
      if(p3.every(x=>x<0)&&f>0.01)addAlert({type:"funding",title:`FUNDING FLIP BULLISH · ${sym}`,body:`${sym} funding flipped from negative to +${f.toFixed(4)}%/8h. Shorts now paying longs — squeeze setup forming. Watch for long entry.`,assets:[sym],id:`fund-bull-${sym}-${Math.floor(Date.now()/3600000)}`});
      else if(p3.every(x=>x>0)&&f<-0.01)addAlert({type:"funding",title:`FUNDING FLIP BEARISH · ${sym}`,body:`${sym} funding turned negative (${f.toFixed(4)}%/8h). Longs now paying — overheated rally may reverse. Consider reducing longs.`,assets:[sym],id:`fund-bear-${sym}-${Math.floor(Date.now()/3600000)}`});
      else if(Math.abs(f)>0.08)addAlert({type:"funding",title:`EXTREME FUNDING · ${sym}`,body:`${sym} funding at ${pct(f,4)}/8h — extreme level. Contrarian signal: ${f>0?"long":"short"} squeeze likely incoming.`,assets:[sym],id:`fund-ext-${sym}-${Math.floor(Date.now()/3600000)}`});
    }
    fundRef.current[sym]=[...hist,f].slice(-10);
  },[addAlert]);

  const checkMacroCountdowns=useCallback(()=>{
    const now=new Date();
    MACRO_EVENTS.forEach(evt=>{
      const[h,m]=evt.timeET.split(":").map(Number);const[y,mo,d]=evt.date.split("-").map(Number);
      const target=new Date(Date.UTC(y,mo-1,d,h+5,m,0));const diffMin=(target-now)/60000;
      [60,30,10,2].forEach(threshold=>{
        const key=`macro-${evt.id}-${threshold}`;
        if(!macroFired.current.has(key)&&diffMin<=threshold&&diffMin>threshold-0.6){
          macroFired.current.add(key);
          const urgency=threshold<=10?"🚨":threshold<=30?"⚠️":"📅";
          addAlert({type:"macro",title:`${urgency} ${evt.bank}: ${evt.name} in ${threshold}min`,body:`${evt.assets?.join(", ")} expected to move ~${evt.expectedMove}%. Forecast: ${evt.forecast}. Position now — volatility spikes at data release.`,assets:evt.assets,id:key});
        }
      });
    });
  },[addAlert]);

  const doHL=useCallback(async()=>{
    try{
      const data=await fetchHyperliquid();
      setCryptoPrices(prev=>{
        const next={...prev};
        Object.entries(data).forEach(([sym,d])=>{
          const oiH=[...(prev[sym]?.oiHistory||[]),d.oi].slice(-20);
          const vH=[...(prev[sym]?.volHistory||[]),d.volume].slice(-20);
          const fH=[...(prev[sym]?.fundHistory||[]),d.funding].slice(-20);
          next[sym]={...prev[sym],...d,oiHistory:oiH,volHistory:vH,fundHistory:fH};
          if(d.volume>0)checkVolumeSpike(sym,d.volume);
          checkFundingFlip(sym,d.funding);
        });
        triggerFlashes(next);return next;
      });
      setHlStatus("live");
    }catch{setHlStatus("error");}
  },[triggerFlashes,checkVolumeSpike,checkFundingFlip]);
  useEffect(()=>{doHL();const iv=setInterval(doHL,3000);return()=>clearInterval(iv);},[doHL]);

  const doFH=useCallback(async()=>{
    try{
      const{stocks,metals,forex}=await fetchFinnhub();
      setEquityPrices(prev=>{const n={...prev,...stocks};triggerFlashes(n);return n;});
      setMetalPrices(prev=>{const n={...prev,...metals};triggerFlashes(n);return n;});
      setForexPrices(prev=>{const n={...prev,...forex};triggerFlashes(n);return n;});
      setFhStatus([...Object.values(stocks),...Object.values(metals),...Object.values(forex)].some(p=>p.live)?"live":"closed");
    }catch{setFhStatus("error");}
  },[triggerFlashes]);
  useEffect(()=>{doFH();const iv=setInterval(doFH,15000);return()=>clearInterval(iv);},[doFH]);

  const allPrices={...cryptoPrices,...equityPrices,...metalPrices,...forexPrices};

  useEffect(()=>{
    const iv=setInterval(()=>{
      setTick(t=>t+1);setLastUpdate(new Date());checkMacroCountdowns();
      if(tick%22===0){const s=SIGNALS_POOL[rndInt(0,SIGNALS_POOL.length-1)];const ns={...s,time:"just now",id:idRef.current++};setSignals(prev=>[ns,...prev.slice(0,11)]);setSigCount(c=>c+1);setFlashSigId(ns.id);setTimeout(()=>setFlashSigId(null),3000);}
    },1000);
    return()=>clearInterval(iv);
  },[tick,checkMacroCountdowns]);

  const toggleWatch=sym=>{const has=watchlist.includes(sym);setWatchlist(prev=>has?prev.filter(s=>s!==sym):[...prev,sym]);setToast(has?`Removed ${sym}`:`${sym} added ✦`);};
  const isWatched=sym=>watchlist.includes(sym);
  const shareSignal=sig=>{navigator.clipboard.writeText(`✦ CLVRQuant SIGNAL\n${sig.icon} ${sig.token} ${sig.dir} | Conf:${sig.conf} | ${sig.lev}\n${sig.desc}`).then(()=>setToast("Signal copied ✦"));};

  const handleSubscribe=async()=>{
    if(!subEmail||!subEmail.includes("@")){setToast("Enter a valid email");return;}
    setSubLoading(true);
    try{if(GAS_WEBHOOK_URL&&GAS_WEBHOOK_URL!=="YOUR_GOOGLE_APPS_SCRIPT_WEBHOOK_URL")await fetch(GAS_WEBHOOK_URL,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({action:"subscribe",email:subEmail,name:subName||"Trader",timestamp:new Date().toISOString()})});setSubList(prev=>[...prev.filter(e=>e!==subEmail),subEmail]);setToast("✦ Subscribed — briefs at 6:00 AM");setSubEmail("");setSubName("");}catch{setToast("Subscribe failed.");}
    setSubLoading(false);
  };

  const generateBrief=async()=>{
    if(ANTHROPIC_KEY==="YOUR_ANTHROPIC_KEY_HERE"){setToast("Add Anthropic key");return;}
    setBriefLoading(true);
    const btc=cryptoPrices["BTC"],eth=cryptoPrices["ETH"],sol=cryptoPrices["SOL"],xau=metalPrices["XAU"],eurusd=forexPrices["EURUSD"],usdjpy=forexPrices["USDJPY"],usdcad=forexPrices["USDCAD"];
    const today=new Date().toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
    try{const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","anthropic-version":"2023-06-01","x-api-key":ANTHROPIC_KEY},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:800,messages:[{role:"user",content:`Brief for ${today}. BTC:${fmt(btc?.price,"BTC")}(${pct(btc?.chg)}) ETH:${fmt(eth?.price,"ETH")}(${pct(eth?.chg)}) SOL:${fmt(sol?.price,"SOL")} XAU:${fmt(xau?.price,"XAU")} EURUSD:${fmt(eurusd?.price,"EURUSD")} USDJPY:${fmt(usdjpy?.price,"USDJPY")} USDCAD:${fmt(usdcad?.price,"USDCAD")}. Write JSON (no markdown): {"headline":"s","bias":"RISK ON|RISK OFF|NEUTRAL","btc":"s","eth":"s","sol":"s","xau":"s","xag":"s","eurusd":"s","usdjpy":"s","usdcad":"s","watchToday":["s","s","s","s","s"],"keyRisk":"s"}`}]}));const data=await res.json();setBriefData(JSON.parse((data.content||[]).map(b=>b.text||"").join("").replace(/\`\`\`json|\`\`\`/g,"").trim()));setBriefDate(today);}catch{setToast("Brief failed.");}
    setBriefLoading(false);
  };

  const runAI=async()=>{
    if(!aiInput.trim()||aiLoading)return;setAiLoading(true);setAiOutput("");
    const snap=(sym,p)=>{const d=p[sym];return d?`${fmt(d.price,sym)}(${pct(d.chg)})${d.live?"✅":"~"}`:"—";};
    const sys=`You are CLVRQuant elite trading AI. CRYPTO:${CRYPTO_SYMS.slice(0,5).map(s=>`${s}:${snap(s,cryptoPrices)}${cryptoPrices[s]?.funding?`F:${pct(cryptoPrices[s].funding,4)}/8h`:""}`).join("|")} STOCKS:${EQUITY_SYMS.slice(0,4).map(s=>`${s}:${snap(s,equityPrices)}`).join("|")} METALS:XAU:${snap("XAU",metalPrices)} FOREX:${FOREX_SYMS.slice(0,4).map(s=>`${s}:${snap(s,forexPrices)}`).join("|")}. Give: DIRECTION/ENTRY/STOP/TP1/TP2/LEVERAGE/CONVICTION/2-line REASON. No disclaimers.`;
    try{const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","anthropic-version":"2023-06-01","x-api-key":ANTHROPIC_KEY},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:500,system:sys,messages:[{role:"user",content:aiInput}]})});if(!res.ok){const e=await res.text();setAiOutput(`Error ${res.status}: ${e}`);setAiLoading(false);return;}const data=await res.json();setAiOutput((data.content||[]).map(b=>b.text||"").join("")||"No response.");}catch(e){setAiOutput(`Error: ${e.message}`);}
    setAiLoading(false);
  };

  const requestPush=async()=>{if(!("Notification" in window)){setToast("Notifications not supported");return;}const p=await Notification.requestPermission();setNotifPerm(p);if(p==="granted")setToast("✦ Push notifications enabled!");else setToast("Blocked in browser settings");};

  // Style helpers
  const Badge=({label,color="gold",style={}})=>{const map={gold:{bg:"rgba(201,168,76,.1)",color:C.gold,border:"rgba(201,168,76,.25)"},green:{bg:"rgba(0,199,135,.1)",color:C.green,border:"rgba(0,199,135,.25)"},red:{bg:"rgba(255,64,96,.1)",color:C.red,border:"rgba(255,64,96,.25)"},orange:{bg:"rgba(255,140,0,.1)",color:C.orange,border:"rgba(255,140,0,.25)"},cyan:{bg:"rgba(0,212,255,.1)",color:C.cyan,border:"rgba(0,212,255,.25)"},blue:{bg:"rgba(59,130,246,.1)",color:C.blue,border:"rgba(59,130,246,.25)"},teal:{bg:"rgba(20,184,166,.1)",color:C.teal,border:"rgba(20,184,166,.25)"},pink:{bg:"rgba(236,72,153,.1)",color:C.pink,border:"rgba(236,72,153,.25)"},purple:{bg:"rgba(168,85,247,.1)",color:C.purple,border:"rgba(168,85,247,.25)"},muted:{bg:"rgba(74,93,128,.1)",color:C.muted2,border:"rgba(74,93,128,.25)"}};const t=map[color]||map.gold;return<span style={{fontSize:8,padding:"2px 7px",borderRadius:2,background:t.bg,color:t.color,border:`1px solid ${t.border}`,fontFamily:MONO,letterSpacing:"0.15em",textTransform:"uppercase",fontWeight:600,...style}}>{label}</span>;};
  const panel={background:C.panel,border:`1px solid ${C.border}`,borderRadius:2,overflow:"hidden",marginBottom:10};
  const ph={display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 14px",borderBottom:`1px solid ${C.border}`,background:"rgba(201,168,76,.03)"};
  const PTitle=({children})=><span style={{fontFamily:SERIF,fontWeight:700,fontSize:13,color:C.white}}>{children}</span>;
  const SLabel=({children})=><div style={{fontFamily:MONO,fontSize:8,letterSpacing:"0.28em",textTransform:"uppercase",color:C.gold,marginBottom:12,display:"flex",alignItems:"center",gap:10}}><span style={{flex:"0 0 24px",height:1,background:`linear-gradient(90deg,${C.gold},transparent)`,display:"inline-block"}}/>{children}</div>;
  const SubBtn=({k,label,col="gold",state,setter})=>{const active=state===k;const ac=col==="green"?C.green:col==="blue"?C.blue:col==="teal"?C.teal:col==="red"?C.red:col==="purple"?C.purple:C.gold;return<button onClick={()=>setter(k)} style={{padding:"5px 11px",borderRadius:2,whiteSpace:"nowrap",outline:"none",cursor:"pointer",fontFamily:MONO,fontSize:8,letterSpacing:"0.12em",textTransform:"uppercase",border:`1px solid ${active?ac:C.border}`,background:active?"rgba(201,168,76,.07)":C.panel,color:active?ac:C.muted2,transition:"all .2s"}}>{label}</button>;};
  const LiveDot=({live})=><div style={{width:5,height:5,borderRadius:"50%",flexShrink:0,background:live?C.green:C.orange,boxShadow:live?`0 0 6px ${C.green}`:"none"}}/>;

  const PriceRow=({sym,d,extra})=>{if(!d)return null;const flash=flashes[sym];const isUp=Number(d.chg)>=0;return(<div style={{padding:"11px 14px",borderBottom:`1px solid ${C.border}`,transition:"background .35s",background:flash==="green"?"rgba(0,199,135,.05)":flash==="red"?"rgba(255,64,96,.05)":"transparent",display:"grid",gridTemplateColumns:"1fr auto auto auto",gap:8,alignItems:"center"}}><div><div style={{display:"flex",alignItems:"center",gap:7}}><span style={{fontFamily:MONO,fontWeight:600,fontSize:12,color:C.text}}>{sym}</span><button onClick={()=>toggleWatch(sym)} style={{background:"none",border:"none",cursor:"pointer",padding:0,fontSize:11,color:isWatched(sym)?C.gold:C.muted,opacity:isWatched(sym)?1:.3}}>✦</button></div>{extra&&<div style={{fontFamily:MONO,fontSize:8,color:C.muted,marginTop:2}}>{extra}</div>}</div><div style={{fontFamily:MONO,fontSize:13,fontWeight:600,color:flash==="green"?C.green:flash==="red"?C.red:C.white,transition:"color .35s"}}>{fmt(d.price,sym)}</div><div style={{fontFamily:MONO,fontSize:10,color:isUp?C.green:C.red,minWidth:50,textAlign:"right"}}>{pct(d.chg)}</div>{d.live?<Badge label="LIVE" color="green"/>:<Badge label="SIM" color="orange"/>}</div>);};

  const SignalRow=({sig})=>(<div style={{padding:"12px 14px",borderBottom:`1px solid ${C.border}`,background:flashSigId===sig.id?"rgba(201,168,76,.03)":"transparent",transition:"background .5s"}}><div style={{display:"grid",gridTemplateColumns:"28px 1fr auto",gap:10,alignItems:"start"}}><div onClick={()=>{setAiInput(`Analyze: ${sig.token} ${sig.dir} — ${sig.desc}`);setTab("ai");}} style={{width:26,height:26,borderRadius:2,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,cursor:"pointer",background:sig.dir==="LONG"?"rgba(0,199,135,.08)":"rgba(255,64,96,.08)",border:`1px solid ${sig.dir==="LONG"?"rgba(0,199,135,.2)":"rgba(255,64,96,.2)"}`}}>{sig.icon}</div><div onClick={()=>{setAiInput(`Analyze: ${sig.token} ${sig.dir} — ${sig.desc}`);setTab("ai");}} style={{cursor:"pointer"}}><div style={{fontFamily:MONO,fontWeight:600,fontSize:11,display:"flex",alignItems:"center",gap:5,flexWrap:"wrap",color:C.text}}>{sig.token}<Badge label={sig.dir} color={sig.dir==="LONG"?"green":"red"}/>{sig.src==="trade.xyz"&&<Badge label="trade.xyz" color="blue"/>}{sig.src==="phantom"&&<Badge label="phantom" color="pink"/>}<span style={{fontSize:8,color:C.muted,fontFamily:MONO}}>{sig.time}</span></div><div style={{fontSize:10,color:C.muted2,lineHeight:1.65,marginTop:3}}>{sig.desc}</div><div style={{display:"flex",gap:3,marginTop:5,flexWrap:"wrap"}}>{sig.tags.map((tg,j)=><Badge key={j} label={tg.l} color={tg.c}/>)}<span style={{fontFamily:MONO,fontSize:8,color:C.muted}}>≤{sig.lev}</span></div></div><div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:5}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:sig.conf>=85?C.gold2:sig.conf>=70?C.gold:C.orange,lineHeight:1}}>{sig.conf}</div><button onClick={()=>shareSignal(sig)} style={{background:"none",border:`1px solid ${C.border}`,borderRadius:2,color:C.muted2,cursor:"pointer",fontFamily:MONO,fontSize:8,padding:"2px 7px"}}>share</button></div></div></div>);

  const todayDate=new Date();
  const bankColor={FED:C.blue,ECB:C.purple,BOJ:C.teal,BOC:C.gold,BOE:C.green,RBA:C.cyan,"US CPI":C.orange,NFP:C.red,PCE:C.orange};
  const upcomingCount=MACRO_EVENTS.filter(e=>{const d=new Date(e.date);return(d-todayDate)/86400000<=7&&(d-todayDate)/86400000>=0;}).length;
  const nextEvents=MACRO_EVENTS.map(e=>{const[y,mo,d]=e.date.split("-").map(Number);const[h,m]=e.timeET.split(":").map(Number);const t=new Date(Date.UTC(y,mo-1,d,h+5,m,0));return{...e,target:t,diffMs:t-todayDate};}).filter(e=>e.diffMs>0).sort((a,b)=>a.diffMs-b.diffMs);
  const filteredMacro=macroFilter==="ALL"?MACRO_EVENTS:MACRO_EVENTS.filter(e=>e.bank===macroFilter||e.bank.startsWith(macroFilter));
  const sortedMacro=[...filteredMacro].sort((a,b)=>new Date(a.date)-new Date(b.date));
  const hlLive=hlStatus==="live",fhLive=fhStatus==="live";
  const filtSigs=signals.filter(s=>{if(sigSubTab==="all")return true;if(sigSubTab==="watch")return watchlist.includes(s.token);if(sigSubTab==="crypto")return s.src==="hyperliquid";if(sigSubTab==="equity")return s.src==="trade.xyz";if(sigSubTab==="metals")return["XAU","XAG"].includes(s.token);if(sigSubTab==="forex")return FOREX_SYMS.includes(s.token);return true;});

  const NAV=[{k:"radar",icon:"📡",label:"Radar"},{k:"prices",icon:"💹",label:"Markets"},{k:"macro",icon:"🏦",label:"Macro"},{k:"signals",icon:"⚡",label:"Signals"},{k:"ai",icon:"✦",label:"AI"}];

  return(
    <div style={{fontFamily:SANS,background:C.bg,color:C.text,minHeight:"100vh",paddingBottom:76,maxWidth:640,margin:"0 auto",position:"relative"}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=IBM+Plex+Mono:wght@300;400;500;600&family=Barlow:wght@300;400;500;600;700&display=swap'); *{-webkit-tap-highlight-color:transparent;box-sizing:border-box;} select,input,textarea{outline:none;} ::-webkit-scrollbar{display:none;} body::before{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(20,30,53,.35) 1px,transparent 1px),linear-gradient(90deg,rgba(20,30,53,.35) 1px,transparent 1px);background-size:60px 60px;pointer-events:none;z-index:0;} body::after{content:'';position:fixed;inset:0;background:radial-gradient(ellipse 80% 40% at 50% 0%,rgba(201,168,76,.05) 0%,transparent 60%);pointer-events:none;z-index:0;} @keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}} @keyframes slideDown{from{transform:translateY(-100%);opacity:0}to{transform:translateY(0);opacity:1}}`}</style>

      {activeAlerts.length>0&&<div style={{animation:"slideDown .3s ease"}}><AlertBanner alerts={activeAlerts} onDismiss={dismissAlert}/></div>}
      {toast&&<Toast msg={toast} onDone={()=>setToast(null)}/>}

      {/* HEADER */}
      <div style={{padding:"12px 14px 10px",borderBottom:`1px solid ${C.border}`,position:"sticky",top:activeAlerts.length>0?68:0,background:"rgba(5,7,9,.96)",zIndex:50,backdropFilter:"blur(14px)",transition:"top .3s"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
          <div><div style={{fontFamily:SERIF,fontWeight:900,fontSize:20,color:C.gold2,letterSpacing:"0.04em",lineHeight:1,textShadow:"0 0 24px rgba(201,168,76,.25)"}}>CLVRQuant</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted,letterSpacing:"0.25em",marginTop:2}}>TRADE SMARTER WITH AI · v2</div></div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            <button onClick={requestPush} style={{background:"none",border:`1px solid ${notifPerm==="granted"?C.gold:C.border}`,borderRadius:2,padding:"4px 8px",cursor:"pointer",fontFamily:MONO,fontSize:10,color:notifPerm==="granted"?C.gold:C.muted2}}>{notifPerm==="granted"?"🔔":"🔕"}</button>
            <div style={{textAlign:"right"}}><div style={{display:"flex",alignItems:"center",gap:5,justifyContent:"flex-end",marginBottom:2}}><LiveDot live={hlLive}/><span style={{fontFamily:MONO,fontSize:7,color:hlLive?C.green:C.orange}}>HL</span><LiveDot live={fhLive}/><span style={{fontFamily:MONO,fontSize:7,color:fhLive?C.green:C.gold}}>FH</span></div><div style={{fontFamily:MONO,fontSize:7,color:C.muted}}>{lastUpdate.toLocaleTimeString()}</div></div>
          </div>
        </div>
        <div style={{display:"flex",gap:5,overflowX:"auto",paddingBottom:2}}>
          {["BTC","ETH","SOL","XAU","XAG","EURUSD","TSLA","NVDA"].map(sym=>{const d=allPrices[sym],flash=flashes[sym];const isUp=Number(d?.chg)>=0;return(<div key={sym} onClick={()=>{setAiInput(`${sym} — long or short right now?`);setTab("ai");}} style={{background:flash==="green"?"rgba(0,199,135,.08)":flash==="red"?"rgba(255,64,96,.06)":C.panel,border:`1px solid ${d?.live?"rgba(201,168,76,.18)":C.border}`,borderRadius:2,padding:"5px 9px",flexShrink:0,cursor:"pointer",minWidth:64,transition:"background .35s"}}><div style={{fontFamily:MONO,fontSize:7,color:d?.live?C.gold:C.muted}}>{sym}</div><div style={{fontFamily:MONO,fontSize:10,fontWeight:600,color:flash==="green"?C.green:flash==="red"?C.red:C.white,transition:"color .35s",marginTop:1}}>{fmt(d?.price,sym)}</div><div style={{fontFamily:MONO,fontSize:8,color:isUp?C.green:C.red}}>{pct(d?.chg)}</div></div>);})}
        </div>
      </div>

      <div style={{padding:"10px 12px",position:"relative",zIndex:1}}>

        {/* ══ RADAR ══ */}
        {tab==="radar"&&<>
          <div style={{marginBottom:14}}><SLabel>Detection Radar · v2</SLabel></div>
          {notifPerm!=="granted"&&<div style={{...panel,border:`1px solid rgba(201,168,76,.25)`,marginBottom:14}}><div style={{padding:"14px 16px",background:"rgba(201,168,76,.05)",display:"flex",alignItems:"center",gap:12}}><span style={{fontSize:22}}>🔔</span><div style={{flex:1}}><div style={{fontFamily:SERIF,fontWeight:700,fontSize:13,color:C.white,marginBottom:4}}>Enable Push Notifications</div><div style={{fontSize:10,color:C.muted2,lineHeight:1.6}}>Get alerted 30min before PCE, NFP, FOMC + real-time volume spikes and funding flips.</div></div><button onClick={requestPush} style={{background:C.gold,color:C.bg,border:"none",borderRadius:2,padding:"8px 14px",fontFamily:SERIF,fontStyle:"italic",fontWeight:700,fontSize:12,cursor:"pointer",flexShrink:0}}>Enable →</button></div></div>}

          {activeAlerts.length>0&&<div style={panel}><div style={ph}><PTitle>⚡ Live Alerts</PTitle><Badge label={`${activeAlerts.length} active`} color="red"/></div>{activeAlerts.map(a=>{const col={macro:C.orange,volume:C.cyan,funding:C.green,liq:C.red,price:C.gold}[a.type]||C.gold;return(<div key={a.id} style={{padding:"11px 14px",borderBottom:`1px solid ${C.border}`,display:"flex",gap:10,alignItems:"flex-start"}}><div style={{flex:1}}><div style={{fontFamily:MONO,fontSize:9,fontWeight:600,color:col,letterSpacing:"0.12em",marginBottom:3}}>{a.title}</div><div style={{fontSize:10,color:C.text,lineHeight:1.65}}>{a.body}</div>{a.assets&&<div style={{display:"flex",gap:4,marginTop:5,flexWrap:"wrap"}}>{a.assets.map(sym=><span key={sym} style={{fontFamily:MONO,fontSize:8,color:col,background:"rgba(0,0,0,.2)",border:`1px solid ${C.border}`,borderRadius:2,padding:"1px 6px"}}>{sym}</span>)}</div>}</div><button onClick={()=>dismissAlert(a.id)} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:16,padding:0}}>×</button></div>);})}</div>}

          {nextEvents.length>0&&(()=>{const e=nextEvents[0];const bc=bankColor[e.bank]||C.gold;const isHot=e.diffMs<30*60*1000;return(<div style={{...panel,border:`1px solid ${isHot?"rgba(255,64,96,.35)":"rgba(201,168,76,.2)"}`,background:isHot?"rgba(255,64,96,.03)":"rgba(201,168,76,.02)"}}><div style={{...ph,background:"transparent"}}><div style={{display:"flex",alignItems:"center",gap:8}}>{isHot&&<div style={{width:8,height:8,borderRadius:"50%",background:C.red,boxShadow:`0 0 8px ${C.red}`,animation:"pulse 1s infinite"}}/>}<PTitle>{isHot?"🚨 IMMINENT":"⏱ Next Event"}</PTitle></div><Badge label={e.impact} color={e.impact==="HIGH"?"red":"orange"}/></div><div style={{padding:"16px 14px"}}><div style={{display:"flex",alignItems:"center",gap:8,marginBottom:12}}><span style={{fontSize:18}}>{e.flag}</span><div><div style={{fontFamily:MONO,fontWeight:600,fontSize:10,color:bc,letterSpacing:"0.1em"}}>{e.bank}</div><div style={{fontFamily:SERIF,fontWeight:700,fontSize:14,color:C.white}}>{e.name}</div><div style={{fontFamily:MONO,fontSize:8,color:C.muted,marginTop:2}}>{e.date} · {e.timeET} ET · Forecast: {e.forecast}</div></div></div><Countdown dateStr={e.date} timeET={e.timeET}/><div style={{marginTop:12,fontSize:10,color:C.muted2,lineHeight:1.7,padding:"8px 10px",background:"rgba(0,0,0,.2)",borderRadius:2,borderLeft:`2px solid ${bc}44`}}>{e.desc}</div><div style={{marginTop:12}}><div style={{fontFamily:MONO,fontSize:8,color:C.muted,letterSpacing:"0.15em",marginBottom:7}}>ASSETS TO WATCH · ~{e.expectedMove}% MOVE EXPECTED</div><div style={{display:"flex",gap:5,flexWrap:"wrap"}}>{e.assets?.map(sym=>{const d=allPrices[sym];return<div key={sym} style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:2,padding:"4px 9px"}}><div style={{fontFamily:MONO,fontSize:7,color:bc}}>{sym}</div><div style={{fontFamily:MONO,fontSize:10,color:C.white}}>{fmt(d?.price,sym)}</div></div>;})}</div></div><button onClick={()=>{setAiInput(`${e.bank} ${e.name} on ${e.date}. Forecast: ${e.forecast}. How to position? Entry, stop, TP for ${e.assets?.join(", ")}.`);setTab("ai");}} style={{width:"100%",height:36,marginTop:12,background:"rgba(201,168,76,.1)",color:C.gold2,border:`1px solid rgba(201,168,76,.3)`,borderRadius:2,fontFamily:SERIF,fontStyle:"italic",fontWeight:700,fontSize:13,cursor:"pointer"}}>Ask AI How to Position →</button></div></div>);})()} 

          {nextEvents.length>1&&<div style={panel}><div style={ph}><PTitle>Upcoming Events</PTitle><Badge label={`${Math.min(nextEvents.length-1,5)} next`} color="gold"/></div>{nextEvents.slice(1,6).map(e=>{const bc=bankColor[e.bank]||C.gold;return(<div key={e.id} style={{padding:"10px 14px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:10}}><span style={{fontSize:14}}>{e.flag}</span><div style={{flex:1}}><div style={{fontFamily:MONO,fontSize:9,color:bc,fontWeight:600}}>{e.bank} · {e.name}</div><div style={{fontFamily:MONO,fontSize:8,color:C.muted,marginTop:2}}>{e.date} · {e.timeET} ET</div></div><Countdown dateStr={e.date} timeET={e.timeET} compact/><Badge label={e.impact} color={e.impact==="HIGH"?"red":"orange"}/></div>);})}</div>}

          {/* VOLUME MONITOR */}
          <div style={panel}><div style={ph}><PTitle>Volume Spike Monitor</PTitle><Badge label="3s" color="cyan"/></div><div style={{padding:"6px 14px 4px",fontFamily:MONO,fontSize:8,color:C.muted,borderBottom:`1px solid ${C.border}`}}>Fires alert when volume exceeds 5× 5-period avg — the exact ETH 20:30 pump signal</div>
          {CRYPTO_SYMS.slice(0,6).map(sym=>{const d=cryptoPrices[sym];const hist=d?.volHistory||[];const avg=hist.length>=2?hist.slice(-5).reduce((a,b)=>a+b,0)/Math.min(5,hist.length):0;const ratio=avg>0&&d?.volume>0?d.volume/avg:1;const spiking=ratio>=3;return(<div key={sym} style={{padding:"9px 14px",borderBottom:`1px solid ${C.border}`,display:"grid",gridTemplateColumns:"56px 1fr auto auto",gap:8,alignItems:"center"}}><span style={{fontFamily:MONO,fontSize:10,color:spiking?C.cyan:C.muted2,fontWeight:spiking?700:400}}>{sym}</span><div style={{position:"relative",height:6,background:"rgba(0,0,0,.3)",borderRadius:1}}><div style={{position:"absolute",left:0,top:0,bottom:0,width:`${Math.min(ratio/8*100,100)}%`,background:spiking?"rgba(0,212,255,.7)":"rgba(201,168,76,.3)",borderRadius:1,transition:"width .5s"}}/></div><span style={{fontFamily:MONO,fontSize:9,color:spiking?C.cyan:C.muted,minWidth:32,textAlign:"right"}}>{ratio.toFixed(1)}×</span>{spiking?<Badge label="SPIKE" color="cyan"/>:<Badge label="ok" color="muted"/>}</div>);})}
          </div>

          {/* FUNDING MONITOR */}
          <div style={panel}><div style={ph}><PTitle>Funding Rate Monitor</PTitle><Badge label="FLIP DETECTOR" color="green"/></div><div style={{padding:"6px 14px 4px",fontFamily:MONO,fontSize:8,color:C.muted,borderBottom:`1px solid ${C.border}`}}>Negative→Positive flip = bullish squeeze. Extreme levels = contrarian reversal signal.</div>
          {CRYPTO_SYMS.slice(0,6).map(sym=>{const d=cryptoPrices[sym];const f=d?.funding||0;const isHot=Math.abs(f)>0.05;const hist=d?.fundHistory||[];const prev=hist.length>=2?hist[hist.length-2]:0;const flipped=prev<0&&f>0.005?"FLIP 🟢":prev>0&&f<-0.005?"FLIP 🔴":"";return(<div key={sym} style={{padding:"9px 14px",borderBottom:`1px solid ${C.border}`,display:"grid",gridTemplateColumns:"56px 1fr auto",gap:8,alignItems:"center"}}><span style={{fontFamily:MONO,fontSize:10,color:C.text}}>{sym}</span><div style={{fontFamily:MONO,fontSize:11,fontWeight:isHot?700:400,color:f>0.03?C.red:f<-0.03?C.green:C.muted2,textAlign:"center"}}>{pct(f,4)}/8h</div><div style={{textAlign:"right"}}>{flipped?<Badge label={flipped} color={flipped.includes("🟢")?"green":"red"}/>:isHot?<Badge label="EXTREME" color={f>0?"red":"green"}/>:<span style={{fontFamily:MONO,fontSize:7,color:C.muted}}>neutral</span>}</div></div>);})}
          </div>

          {/* LIQUIDATION HEATMAP */}
          <div style={panel}><div style={ph}><PTitle>Liquidation Heatmap</PTitle><div style={{display:"flex",gap:4}}>{["BTC","ETH","SOL","XAU"].map(s=><button key={s} onClick={()=>setLiqSym(s)} style={{padding:"2px 8px",borderRadius:2,border:`1px solid ${liqSym===s?C.gold:C.border}`,background:"none",color:liqSym===s?C.gold:C.muted2,fontFamily:MONO,fontSize:8,cursor:"pointer"}}>{s}</button>)}</div></div><div style={{padding:"6px 14px 4px",fontFamily:MONO,fontSize:8,color:C.muted,borderBottom:`1px solid ${C.border}`}}>Estimated stop clusters · Red bars = short liquidations above · Green bars = long liquidations below</div><div style={{padding:"14px 14px"}}><LiqHeatmap sym={liqSym} price={allPrices[liqSym]?.price}/></div></div>
        </>}

        {/* ══ PRICES ══ */}
        {tab==="prices"&&<>
          <div style={{marginBottom:14}}><SLabel>Market Data</SLabel></div>
          <div style={{display:"flex",gap:4,marginBottom:10,overflowX:"auto"}}>{[{k:"crypto",l:"Crypto"},{k:"equity",l:"Equities",col:"blue"},{k:"metals",l:"Metals"},{k:"forex",l:"Forex",col:"teal"}].map(t=>(<SubBtn key={t.k} k={t.k} label={t.l} col={t.col||"gold"} state={priceTab} setter={setPriceTab}/>))}</div>
          {priceTab==="crypto"&&<div style={panel}><div style={ph}><PTitle>Crypto · Hyperliquid</PTitle><Badge label={hlLive?"LIVE":"Connecting"} color={hlLive?"green":"orange"}/></div>{CRYPTO_SYMS.map(sym=>{const d=cryptoPrices[sym];return(<div key={sym}><PriceRow sym={sym} d={d} extra={d?.live&&d.funding?`Fund: ${pct(d.funding,4)}/8h · OI: $${(d.oi/1e6).toFixed(0)}M`:null}/>{d?.oiHistory?.length>3&&<div style={{padding:"2px 14px 8px",display:"flex",alignItems:"center",gap:8}}><span style={{fontFamily:MONO,fontSize:7,color:C.muted,flexShrink:0}}>OI</span><Sparkline data={d.oiHistory} width={90} height={18}/></div>}</div>);})}</div>}
          {priceTab==="equity"&&<div style={panel}><div style={ph}><PTitle>Equities</PTitle><Badge label={fhLive?"Live":"Closed"} color={fhLive?"green":"gold"}/></div>{EQUITY_SYMS.map(sym=><PriceRow key={sym} sym={sym} d={equityPrices[sym]}/>)}</div>}
          {priceTab==="metals"&&<div style={panel}><div style={ph}><PTitle>Precious Metals</PTitle></div>{METALS_SYMS.map(sym=><PriceRow key={sym} sym={sym} d={metalPrices[sym]}/>)}<div style={{padding:"10px 14px",fontFamily:MONO,fontSize:9,color:C.muted2}}>Gold/Silver: <span style={{color:C.gold2}}>{metalPrices.XAU?.price&&metalPrices.XAG?.price?(metalPrices.XAU.price/metalPrices.XAG.price).toFixed(0):"—"}:1</span></div></div>}
          {priceTab==="forex"&&<div style={panel}><div style={ph}><PTitle>Forex</PTitle><Badge label={fhLive?"Live":"Closed"} color={fhLive?"green":"gold"}/></div>{FOREX_SYMS.map(sym=><PriceRow key={sym} sym={sym} d={forexPrices[sym]}/>)}</div>}
        </>}

        {/* ══ MACRO ══ */}
        {tab==="macro"&&<>
          <div style={{marginBottom:14}}><SLabel>Central Bank Calendar</SLabel></div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8,marginBottom:14}}>{[{label:"This Week",val:upcomingCount,col:C.red},{label:"Next 30d",val:MACRO_EVENTS.filter(e=>{const d=new Date(e.date);return(d-todayDate)/864e5<=30&&(d-todayDate)/864e5>=0;}).length,col:C.gold},{label:"HIGH Impact",val:MACRO_EVENTS.filter(e=>e.impact==="HIGH").length,col:C.orange}].map(s=>(<div key={s.label} style={{...panel,marginBottom:0,padding:"12px",textAlign:"center"}}><div style={{fontFamily:MONO,fontSize:7,color:C.muted,letterSpacing:"0.15em",marginBottom:5}}>{s.label}</div><div style={{fontFamily:SERIF,fontWeight:900,fontSize:26,color:s.col,lineHeight:1}}>{s.val}</div></div>))}</div>
          <div style={{display:"flex",gap:4,marginBottom:10,overflowX:"auto"}}>{["ALL","FED","ECB","BOJ","BOC","BOE","DATA"].map(b=>(<SubBtn key={b} k={b==="DATA"?"US CPI":b} label={b} col={b==="FED"?"blue":b==="ECB"?"purple":b==="BOJ"?"teal":b==="BOC"?"gold":b==="BOE"?"green":b==="DATA"?"orange":"gold"} state={macroFilter} setter={setMacroFilter}/>))}</div>
          <div style={panel}><div style={ph}><PTitle>Events with Live Countdown</PTitle><Badge label={`${sortedMacro.length}`} color="gold"/></div>
          {sortedMacro.map(evt=>{const[y,mo,d]=evt.date.split("-").map(Number);const[h,m]=evt.timeET.split(":").map(Number);const target=new Date(Date.UTC(y,mo-1,d,h+5,m,0));const isPast=target<todayDate;const diffMs=target-todayDate;const isHot=diffMs>0&&diffMs<30*60*1000;const bc=bankColor[evt.bank]||C.gold;
          return(<div key={evt.id} style={{padding:"13px 14px",borderBottom:`1px solid ${C.border}`,background:isHot?"rgba(255,64,96,.04)":isPast?"rgba(0,0,0,.1)":"transparent",opacity:isPast?.55:1}}><div style={{display:"flex",alignItems:"flex-start",justifyContent:"space-between",gap:8,marginBottom:8}}><div style={{flex:1}}><div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap",marginBottom:5}}><span style={{fontSize:13}}>{evt.flag}</span><span style={{fontFamily:MONO,fontWeight:600,fontSize:10,color:bc}}>{evt.bank}</span><Badge label={evt.impact} color={evt.impact==="HIGH"?"red":evt.impact==="MED"?"orange":"teal"}/>{isHot&&<Badge label="LIVE SOON" color="red" style={{animation:"pulse 1.4s ease infinite"}}/>}</div><div style={{fontFamily:SERIF,fontWeight:700,fontSize:13,color:C.white,marginBottom:3}}>{evt.name}</div><div style={{fontFamily:MONO,fontSize:8,color:C.muted}}>{evt.date} · {evt.timeET} ET{evt.forecast!=="—"?` · Forecast: ${evt.forecast}`:""}</div></div>{!isPast&&<Countdown dateStr={evt.date} timeET={evt.timeET} compact/>}</div>
          <div style={{fontSize:10,color:C.muted2,lineHeight:1.7,padding:"8px 10px",background:"rgba(0,0,0,.18)",borderRadius:2,borderLeft:`2px solid ${bc}33`,marginBottom:8}}>{evt.desc}</div>
          {evt.assets&&<div style={{display:"flex",gap:4,flexWrap:"wrap",marginBottom:8}}><span style={{fontFamily:MONO,fontSize:7,color:C.muted,marginTop:2}}>WATCH:</span>{evt.assets.map(sym=><span key={sym} style={{fontFamily:MONO,fontSize:8,color:bc,background:"rgba(0,0,0,.2)",border:`1px solid ${C.border}`,borderRadius:2,padding:"1px 6px"}}>{sym}</span>)}<span style={{fontFamily:MONO,fontSize:8,color:C.orange}}>~{evt.expectedMove}%</span></div>}
          <div style={{display:"flex",gap:6}}><button onClick={()=>{setAiInput(`${evt.bank} ${evt.name} on ${evt.date}: forecast ${evt.forecast}. How to position? Entry, stop, TP.`);setTab("ai");}} style={{background:"none",border:`1px solid ${C.border}`,color:C.muted2,borderRadius:2,padding:"3px 9px",fontFamily:MONO,fontSize:7,cursor:"pointer"}}>Ask AI ✦</button><button onClick={()=>{const cal=`BEGIN:VCALENDAR\nVERSION:2.0\nBEGIN:VEVENT\nSUMMARY:${evt.bank} - ${evt.name}\nDTSTART:${evt.date.replace(/-/g,"")}\nDTEND:${evt.date.replace(/-/g,"")}\nDESCRIPTION:${evt.desc}\nEND:VEVENT\nEND:VCALENDAR`;const blob=new Blob([cal],{type:"text/calendar"});const url=URL.createObjectURL(blob);const a=document.createElement("a");a.href=url;a.download=`${evt.bank}-${evt.date}.ics`;a.click();setToast("✦ Calendar event saved");}} style={{background:"none",border:`1px solid ${C.border}`,color:C.muted2,borderRadius:2,padding:"3px 9px",fontFamily:MONO,fontSize:7,cursor:"pointer"}}>Add to Cal</button></div>
          </div>);})}
          </div>
        </>}

        {/* ══ SIGNALS ══ */}
        {tab==="signals"&&<><div style={{marginBottom:14}}><SLabel>Quant AI Signals</SLabel></div><div style={{display:"flex",gap:4,marginBottom:10,overflowX:"auto"}}>{[{k:"all",l:"All"},{k:"watch",l:"✦ Watch"},{k:"crypto",l:"Crypto",col:"green"},{k:"equity",l:"Equities",col:"blue"},{k:"metals",l:"Metals"},{k:"forex",l:"Forex",col:"teal"}].map(t=>(<SubBtn key={t.k} k={t.k} label={t.l} col={t.col||"gold"} state={sigSubTab} setter={setSigSubTab}/>))}</div><div style={panel}><div style={ph}><PTitle>Alpha Signals</PTitle><Badge label={`${sigCount} total`} color="gold"/></div>{filtSigs.map(sig=><SignalRow key={sig.id} sig={sig}/>)}</div></>}

        {/* ══ AI ══ */}
        {tab==="ai"&&<><div style={{marginBottom:14}}><SLabel>AI Market Analyst</SLabel></div><div style={panel}><div style={ph}><PTitle>CLVRQuant AI</PTitle><Badge label="Claude · Live" color="gold"/></div><div style={{padding:16}}>{ANTHROPIC_KEY==="YOUR_ANTHROPIC_KEY_HERE"&&<div style={{background:"rgba(255,140,0,.07)",border:`1px solid rgba(255,140,0,.2)`,borderRadius:2,padding:"9px 12px",marginBottom:12,fontFamily:MONO,fontSize:8,color:C.orange}}>⚠ Add Anthropic API key in App.js</div>}<div style={{display:"flex",gap:4,marginBottom:10,flexWrap:"wrap"}}>{["BTC","ETH","SOL","XAU","EURUSD","TSLA","NVDA"].map(sym=>{const d=allPrices[sym];return<button key={sym} onClick={()=>setAiInput(`${sym} — long or short? Price:${fmt(d?.price,sym)} 24h:${pct(d?.chg)}`)} style={{padding:"4px 10px",borderRadius:2,border:`1px solid ${d?.live?"rgba(201,168,76,.28)":C.border}`,background:C.panel,color:d?.live?C.gold2:C.muted2,fontFamily:MONO,fontSize:8,cursor:"pointer"}}>{sym}{d?.live?" ✦":""}</button>;})}</div><textarea value={aiInput} onChange={e=>setAiInput(e.target.value)} placeholder={`"Long BTC now?" · "How to trade the PCE print?" · "Is XAU overextended?"`} style={{width:"100%",background:C.inputBg,border:`1px solid ${C.border}`,borderRadius:2,padding:12,color:C.text,fontFamily:SANS,fontSize:11,resize:"none",height:72,lineHeight:1.7}}/><button onClick={runAI} disabled={aiLoading} style={{width:"100%",height:44,marginTop:8,background:"rgba(201,168,76,.1)",color:aiLoading?C.muted:C.gold2,border:`1px solid rgba(201,168,76,.3)`,borderRadius:2,fontFamily:SERIF,fontStyle:"italic",fontWeight:700,fontSize:15,cursor:aiLoading?"not-allowed":"pointer"}}>{aiLoading?"Analyzing...":"Analyze →"}</button>{aiOutput&&<div style={{marginTop:12,background:C.inputBg,border:`1px solid ${C.border}`,borderRadius:2,padding:14,fontSize:11,lineHeight:1.9,color:C.text,whiteSpace:"pre-wrap",maxHeight:320,overflowY:"auto"}}>{aiOutput}</div>}</div></div><div style={{...panel,border:`1px solid rgba(255,140,0,.12)`}}><div style={{padding:"11px 14px"}}><div style={{fontFamily:MONO,fontSize:7,color:C.orange,letterSpacing:"0.22em",marginBottom:5}}>⚠ LEGAL DISCLAIMER</div><div style={{fontSize:9,color:C.muted,lineHeight:1.9}}>CLVRQuant is for <strong style={{color:C.muted2}}>informational purposes only</strong>. Not financial advice. AI signals are not recommendations. All trading involves risk. © 2025 CLVRQuant · Mike Claver™. All rights reserved.</div></div></div></>}

        <div style={{textAlign:"center",fontFamily:MONO,fontSize:7,color:C.muted,marginTop:6,letterSpacing:"0.12em"}}>HYPERLIQUID · FINNHUB · NOT FINANCIAL ADVICE · © 2025 CLVRQUANT</div>
      </div>

      {/* BOTTOM NAV */}
      <div style={{position:"fixed",bottom:0,left:0,right:0,zIndex:100,background:"rgba(5,7,9,.97)",borderTop:`1px solid ${C.border}`,backdropFilter:"blur(14px)",display:"flex",paddingBottom:"env(safe-area-inset-bottom,0px)"}}>
        {NAV.map(item=>{const active=tab===item.k;const hasAlert=(item.k==="radar"&&activeAlerts.length>0)||(item.k==="macro"&&upcomingCount>0);return(<button key={item.k} onClick={()=>setTab(item.k)} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"8px 2px 10px",background:"none",border:"none",borderTop:`2px solid ${active?C.gold:"transparent"}`,position:"relative",cursor:"pointer",transition:"border-color .2s"}}><span style={{fontSize:item.k==="ai"?16:18,lineHeight:1,fontFamily:item.k==="ai"?SERIF:"inherit",fontWeight:item.k==="ai"?900:"inherit",color:active?C.gold:C.muted2}}>{item.icon}</span>{hasAlert&&!active&&<div style={{position:"absolute",top:5,right:"calc(50% - 14px)",width:7,height:7,borderRadius:"50%",background:C.red,animation:"pulse 1.2s infinite"}}/>}<span style={{fontFamily:MONO,fontSize:7,marginTop:4,color:active?C.gold:C.muted,letterSpacing:"0.15em",fontWeight:active?600:400,textTransform:"uppercase"}}>{item.label}</span></button>);})}
      </div>
    </div>
  );
}
