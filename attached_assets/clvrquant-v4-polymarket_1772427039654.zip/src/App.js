// ─────────────────────────────────────────────────────────
// CLVRQuant v4
// NEW: Polymarket integration
//   • Live prediction market odds (Fed, CPI, NFP, BTC targets, Trump policy)
//   • Odds overlaid on Radar macro event cards
//   • AI analyst receives Polymarket context
//   • Alert when odds shift >10% in <1 hour
// ALSO: Social intelligence layer (v3)
//   • CryptoPanic API  — CT news + sentiment scores (free)
//   • Twitter/X        — WhaleAlert, lookonchain, tier10k via RapidAPI
//   • Truth Social     — Trump RSS feed (free)
//   • Reddit           — r/wallstreetbets + r/CryptoCurrency (free API)
//
// Integration:
//   • "Social" tab   — live sentiment feed with scores
//   • Alert banner   — fires when tracked asset mentioned
//   • AI context     — social signals fed into every AI call
// ─────────────────────────────────────────────────────────

// ── API KEYS ─────────────────────────────────────────────
const FINNHUB_KEY      = "YOUR_FINNHUB_KEY_HERE";
const ANTHROPIC_KEY    = "YOUR_ANTHROPIC_KEY_HERE";
const GAS_WEBHOOK_URL  = "YOUR_GOOGLE_APPS_SCRIPT_WEBHOOK_URL";
const CRYPTOPANIC_KEY  = "YOUR_CRYPTOPANIC_KEY_HERE";   // free at cryptopanic.com
const RAPIDAPI_KEY     = "YOUR_RAPIDAPI_KEY_HERE";       // rapidapi.com → "Twitter135" ~$10/mo

import { useState, useEffect, useRef, useCallback } from "react";

// ── THEME ─────────────────────────────────────────────────
const C = {
  bg:"#050709",navy:"#080d18",panel:"#0c1220",border:"#141e35",border2:"#1c2b4a",
  gold:"#c9a84c",gold2:"#e8c96d",gold3:"#f7e0a0",
  text:"#c8d4ee",muted:"#4a5d80",muted2:"#6b7fa8",white:"#f0f4ff",
  green:"#00c787",red:"#ff4060",orange:"#ff8c00",
  cyan:"#00d4ff",blue:"#3b82f6",teal:"#14b8a6",purple:"#a855f7",pink:"#ec4899",
  inputBg:"#080d18",
};
const SERIF = "'Playfair Display',Georgia,serif";
const MONO  = "'IBM Plex Mono',monospace";
const SANS  = "'Barlow',system-ui,sans-serif";

// ── HELPERS ───────────────────────────────────────────────
const pct=(v,d=2)=>{const n=Number(v);if(isNaN(n))return"—";return(n>=0?"+":"")+n.toFixed(d)+"%";};
const fmt=(p,sym)=>{
  if(!p&&p!==0)return"—";p=Number(p);if(isNaN(p)||p===0)return"—";
  if(["EURUSD","GBPUSD","AUDUSD","USDCHF"].includes(sym))return p.toFixed(4);
  if(["USDJPY","USDCAD"].includes(sym))return p.toFixed(2);
  if(sym==="XAG")return"$"+p.toFixed(2);if(sym==="XAU")return"$"+p.toFixed(0);
  if(p>=1000)return"$"+p.toFixed(0);if(p>=100)return"$"+p.toFixed(1);
  if(p>=1)return"$"+p.toFixed(2);return"$"+p.toFixed(6);
};
const timeAgo=ts=>{const s=Math.floor((Date.now()-new Date(ts))/1000);if(s<60)return`${s}s`;if(s<3600)return`${Math.floor(s/60)}m`;if(s<86400)return`${Math.floor(s/3600)}h`;return`${Math.floor(s/86400)}d`;};
const rndInt=(a,b)=>Math.floor(a+Math.random()*(b-a+1));

// ── BASE DATA ─────────────────────────────────────────────
const CRYPTO_BASE={BTC:84000,ETH:1590,SOL:130,WIF:0.82,DOGE:0.168,AVAX:20.1,LINK:12.8,ARB:0.38,PEPE:0.0000072};
const EQUITY_BASE={TSLA:248,NVDA:103,AAPL:209,GOOGL:155,META:558,MSFT:388,AMZN:192,MSTR:310};
const METALS_BASE={XAU:3285,XAG:32.8};
const FOREX_BASE={EURUSD:1.0842,GBPUSD:1.2715,USDJPY:149.82,USDCHF:0.9012,AUDUSD:0.6524,USDCAD:1.3654};
const CRYPTO_SYMS=Object.keys(CRYPTO_BASE);
const EQUITY_SYMS=Object.keys(EQUITY_BASE);
const METALS_SYMS=Object.keys(METALS_BASE);
const FOREX_SYMS=Object.keys(FOREX_BASE);
const FH_METALS={XAU:"OANDA:XAU_USD",XAG:"OANDA:XAG_USD"};
const FH_FOREX={EURUSD:"OANDA:EUR_USD",GBPUSD:"OANDA:GBP_USD",USDJPY:"OANDA:USD_JPY",USDCHF:"OANDA:USD_CHF",AUDUSD:"OANDA:AUD_USD",USDCAD:"OANDA:USD_CAD"};
const ALL_SYMS=[...CRYPTO_SYMS,...EQUITY_SYMS,...METALS_SYMS,...FOREX_SYMS];

// ── TWITTER ACCOUNTS TO MONITOR ───────────────────────────
const TWITTER_ACCOUNTS=[
  {handle:"whale_alert",   label:"Whale Alert",   icon:"🐋", color:"cyan",   tags:["whale","on-chain"]},
  {handle:"lookonchain",   label:"LookOnChain",   icon:"🔍", color:"blue",   tags:["smart-money","on-chain"]},
  {handle:"tier10k",       label:"tier10k",       icon:"📊", color:"gold",   tags:["macro","sentiment"]},
  {handle:"inversebrah",   label:"InverseBrah",   icon:"🎯", color:"purple", tags:["sentiment","TA"]},
  {handle:"CryptoKaleo",   label:"Kaleo",         icon:"🌊", color:"teal",   tags:["TA","altcoin"]},
  {handle:"zerohedge",     label:"ZeroHedge",     icon:"⚡", color:"orange", tags:["macro","bearish"]},
];

// ── MACRO EVENTS ──────────────────────────────────────────
const MACRO_EVENTS=[
  {id:1,bank:"FED",flag:"🇺🇸",name:"FOMC Rate Decision",date:"2025-03-19",timeET:"14:00",current:"4.25–4.50%",forecast:"Hold",impact:"HIGH",desc:"Fed decision. Watch dot plot & Powell presser.",assets:["BTC","ETH","XAU","EURUSD","USDJPY"],expectedMove:3.5},
  {id:2,bank:"FED",flag:"🇺🇸",name:"FOMC Rate Decision",date:"2025-05-07",timeET:"14:00",current:"4.25–4.50%",forecast:"Hold",impact:"HIGH",desc:"Second FOMC 2025.",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:3.0},
  {id:3,bank:"FED",flag:"🇺🇸",name:"FOMC Rate Decision",date:"2025-06-18",timeET:"14:00",current:"4.25–4.50%",forecast:"–25bp",impact:"HIGH",desc:"June FOMC — first cut possible.",assets:["BTC","ETH","XAU","EURUSD","USDJPY"],expectedMove:4.5},
  {id:4,bank:"ECB",flag:"🇪🇺",name:"ECB Rate Decision",date:"2025-03-06",timeET:"09:15",current:"3.15%",forecast:"–25bp",impact:"HIGH",desc:"ECB cut expected. Lagarde presser key.",assets:["EURUSD","GBPUSD","XAU"],expectedMove:2.5},
  {id:5,bank:"ECB",flag:"🇪🇺",name:"ECB Rate Decision",date:"2025-04-17",timeET:"09:15",current:"2.90%",forecast:"–25bp",impact:"HIGH",desc:"Second ECB cut.",assets:["EURUSD","GBPUSD"],expectedMove:2.0},
  {id:6,bank:"BOJ",flag:"🇯🇵",name:"BOJ Rate Decision",date:"2025-03-19",timeET:"02:00",current:"0.50%",forecast:"Hold",impact:"HIGH",desc:"BOJ on hold. Hawkish surprise = JPY rally.",assets:["USDJPY","AUDUSD"],expectedMove:2.0},
  {id:7,bank:"BOJ",flag:"🇯🇵",name:"BOJ Rate Decision",date:"2025-05-01",timeET:"02:00",current:"0.50%",forecast:"+25bp",impact:"HIGH",desc:"BOJ may hike. USD/JPY very sensitive.",assets:["USDJPY"],expectedMove:3.0},
  {id:8,bank:"BOC",flag:"🇨🇦",name:"BOC Rate Decision",date:"2025-03-12",timeET:"09:45",current:"3.00%",forecast:"Hold",impact:"HIGH",desc:"BOC on hold.",assets:["USDCAD"],expectedMove:1.5},
  {id:9,bank:"BOC",flag:"🇨🇦",name:"BOC Rate Decision",date:"2025-04-16",timeET:"09:45",current:"3.00%",forecast:"–25bp",impact:"HIGH",desc:"BOC may resume cutting.",assets:["USDCAD"],expectedMove:2.0},
  {id:10,bank:"BOE",flag:"🇬🇧",name:"BOE Rate Decision",date:"2025-03-20",timeET:"12:00",current:"4.50%",forecast:"Hold",impact:"HIGH",desc:"BOE holds.",assets:["GBPUSD"],expectedMove:1.5},
  {id:11,bank:"US CPI",flag:"🇺🇸",name:"US CPI Inflation",date:"2025-03-12",timeET:"08:30",current:"3.0%",forecast:"2.9%",impact:"HIGH",desc:"Soft print = rate cut catalyst. BTC, gold, forex move.",assets:["BTC","ETH","XAU","EURUSD","USDJPY"],expectedMove:4.0},
  {id:12,bank:"US CPI",flag:"🇺🇸",name:"US CPI Inflation",date:"2025-04-10",timeET:"08:30",current:"—",forecast:"—",impact:"HIGH",desc:"April CPI.",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:4.0},
  {id:13,bank:"NFP",flag:"🇺🇸",name:"Non-Farm Payrolls",date:"2025-03-07",timeET:"08:30",current:"256K",forecast:"175K",impact:"HIGH",desc:"Weak NFP = dovish Fed = crypto/gold rally.",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:3.5},
  {id:14,bank:"NFP",flag:"🇺🇸",name:"Non-Farm Payrolls",date:"2025-04-04",timeET:"08:30",current:"—",forecast:"—",impact:"HIGH",desc:"April NFP.",assets:["BTC","ETH","XAU"],expectedMove:3.5},
  {id:15,bank:"PCE",flag:"🇺🇸",name:"US PCE Inflation",date:"2025-03-28",timeET:"08:30",current:"2.6%",forecast:"2.5%",impact:"HIGH",desc:"Fed's preferred gauge. ETH pumped 3% on Feb 28 soft print.",assets:["BTC","ETH","SOL","XAU","EURUSD"],expectedMove:3.0},
  {id:16,bank:"PCE",flag:"🇺🇸",name:"US PCE Inflation",date:"2025-04-30",timeET:"08:30",current:"—",forecast:"—",impact:"HIGH",desc:"April PCE. Crucial for Fed path.",assets:["BTC","ETH","XAU","EURUSD"],expectedMove:3.0},
];

const SIGNALS_POOL=[
  {icon:"🚀",dir:"LONG",token:"SOL",conf:94,lev:"10x",src:"hyperliquid",desc:"Smart money +$2.4M in 18min. Short squeeze incoming.",tags:[{l:"ON-CHAIN",c:"green"},{l:"LIQ SWEEP",c:"cyan"}]},
  {icon:"📉",dir:"SHORT",token:"BTC",conf:81,lev:"5x",src:"hyperliquid",desc:"OI at resistance. Extreme funding. Reversal setup.",tags:[{l:"FUNDING",c:"orange"},{l:"RESISTANCE",c:"red"}]},
  {icon:"🔥",dir:"LONG",token:"WIF",conf:88,lev:"3x",src:"hyperliquid",desc:"Whale 0x7f3 opened 8.4M WIF. Same wallet +340% on BONK.",tags:[{l:"WHALE",c:"orange"},{l:"NEUTRAL FUND",c:"green"}]},
  {icon:"📈",dir:"LONG",token:"TSLA",conf:86,lev:"5x",src:"trade.xyz",desc:"Earnings beat whisper +18%. Smart money $3.1M long.",tags:[{l:"EARNINGS",c:"gold"},{l:"WHALE",c:"orange"}]},
  {icon:"🚀",dir:"LONG",token:"NVDA",conf:91,lev:"5x",src:"trade.xyz",desc:"H100 supply +40% Taiwan shipments detected.",tags:[{l:"SUPPLY CHAIN",c:"cyan"},{l:"NEG FUND",c:"green"}]},
  {icon:"🥇",dir:"LONG",token:"XAU",conf:89,lev:"5x",src:"phantom",desc:"Central bank gold buying +42t. DXY weakening.",tags:[{l:"MACRO",c:"gold"},{l:"CENTRAL BANK",c:"teal"}]},
  {icon:"💱",dir:"SHORT",token:"USDJPY",conf:84,lev:"10x",src:"phantom",desc:"BOJ hawkish minutes. JPY intervention risk ¥150.",tags:[{l:"BOJ",c:"teal"},{l:"INTERVENTION",c:"red"}]},
  {icon:"📊",dir:"LONG",token:"EURUSD",conf:79,lev:"10x",src:"phantom",desc:"ECB holds, Fed cutting. Rate differential narrowing.",tags:[{l:"RATE DIFF",c:"blue"},{l:"LIQ SWEEP",c:"green"}]},
];

// ── POLYMARKET MARKETS ────────────────────────────────────
// Maps to gamma-api.polymarket.com — free, no auth required
// Slugs verified against live Polymarket markets
const POLY_MARKETS = [
  // Macro / Fed
  { id:"fed-cut-march",   cat:"macro",   label:"Fed cuts rates in March?",          slug:"will-the-fed-cut-rates-at-the-march-2025-meeting",    assets:["BTC","ETH","XAU","EURUSD"], macroId:1 },
  { id:"fed-cut-may",     cat:"macro",   label:"Fed cuts rates in May?",             slug:"will-the-fed-cut-rates-at-the-may-2025-meeting",      assets:["BTC","ETH","XAU"],          macroId:2 },
  { id:"fed-cut-june",    cat:"macro",   label:"Fed cuts by June 2025?",             slug:"will-the-federal-reserve-cut-rates-by-june-2025",    assets:["BTC","XAU","EURUSD"],       macroId:3 },
  { id:"cpi-below-3",     cat:"macro",   label:"CPI below 3% in March?",             slug:"will-us-cpi-be-below-3-percent-in-march-2025",       assets:["BTC","XAU","EURUSD"],       macroId:11 },
  { id:"pce-soft",        cat:"macro",   label:"PCE below 2.5% in March?",           slug:"will-us-pce-be-below-25-in-march-2025",              assets:["BTC","ETH","SOL"],          macroId:15 },
  { id:"recession-2025",  cat:"macro",   label:"US recession in 2025?",              slug:"us-recession-in-2025",                               assets:["XAU","BTC","USDJPY"],       macroId:null },
  // Crypto price targets
  { id:"btc-100k",        cat:"crypto",  label:"BTC hits $100k before June?",        slug:"will-bitcoin-reach-100000-before-june-2025",         assets:["BTC"],                      macroId:null },
  { id:"btc-150k",        cat:"crypto",  label:"BTC hits $150k in 2025?",            slug:"will-bitcoin-reach-150000-in-2025",                  assets:["BTC"],                      macroId:null },
  { id:"eth-5k",          cat:"crypto",  label:"ETH hits $5k in 2025?",              slug:"will-ethereum-reach-5000-in-2025",                   assets:["ETH"],                      macroId:null },
  { id:"eth-3k",          cat:"crypto",  label:"ETH hits $3k before June?",          slug:"will-ethereum-reach-3000-before-june-2025",          assets:["ETH"],                      macroId:null },
  { id:"sol-200",         cat:"crypto",  label:"SOL hits $200 in 2025?",             slug:"will-solana-reach-200-in-2025",                      assets:["SOL"],                      macroId:null },
  { id:"btc-strategic",   cat:"crypto",  label:"US strategic BTC reserve?",          slug:"will-us-establish-a-strategic-bitcoin-reserve",      assets:["BTC","ETH"],                macroId:null },
  // Trump / political
  { id:"trump-tariff-90", cat:"trump",   label:"Trump pauses all tariffs?",          slug:"will-trump-pause-all-tariffs-90-days",               assets:["BTC","XAU","EURUSD"],       macroId:null },
  { id:"trump-crypto-eo", cat:"trump",   label:"Trump signs crypto EO in 2025?",     slug:"will-trump-sign-crypto-executive-order-2025",        assets:["BTC","ETH","SOL"],          macroId:null },
  { id:"trump-china",     cat:"trump",   label:"US-China trade deal in 2025?",       slug:"us-china-trade-deal-2025",                           assets:["BTC","XAU","USDCAD"],       macroId:null },
  { id:"doge-budget",     cat:"trump",   label:"DOGE cuts $1T from budget?",         slug:"will-doge-cut-1-trillion-from-federal-budget-2025",  assets:["XAU","BTC"],                macroId:null },
  { id:"dollar-collapse", cat:"trump",   label:"DXY drops 10%+ in 2025?",            slug:"will-the-dollar-index-drop-10-percent-2025",         assets:["XAU","BTC","EURUSD"],       macroId:null },
];

// Fallback mock odds (used when API fails / CORS blocks)
const POLY_MOCK = {
  "fed-cut-march":  { yes:14, prev:18 },
  "fed-cut-may":    { yes:38, prev:35 },
  "fed-cut-june":   { yes:68, prev:60 },
  "cpi-below-3":    { yes:62, prev:65 },
  "pce-soft":       { yes:70, prev:64 },
  "recession-2025": { yes:45, prev:42 },
  "btc-100k":       { yes:38, prev:41 },
  "btc-150k":       { yes:22, prev:20 },
  "eth-5k":         { yes:18, prev:16 },
  "eth-3k":         { yes:35, prev:30 },
  "sol-200":        { yes:28, prev:25 },
  "btc-strategic":  { yes:82, prev:78 },
  "trump-tariff-90":{ yes:32, prev:38 },
  "trump-crypto-eo":{ yes:74, prev:70 },
  "trump-china":    { yes:28, prev:25 },
  "doge-budget":    { yes:18, prev:22 },
  "dollar-collapse":{ yes:24, prev:21 },
};

async function fetchPolymarket() {
  // Try live Polymarket gamma API (free, no auth)
  const results = {};
  try {
    // Fetch multiple markets in parallel using the gamma API
    const fetches = POLY_MARKETS.slice(0, 8).map(async (m) => {
      try {
        const r = await fetch(
          `https://gamma-api.polymarket.com/markets?slug=${m.slug}&limit=1`,
          { headers: { "Accept": "application/json" }, signal: AbortSignal.timeout(4000) }
        );
        if (!r.ok) return null;
        const d = await r.json();
        const market = Array.isArray(d) ? d[0] : d?.markets?.[0];
        if (!market) return null;
        // outcomePrices is array like ["0.38","0.62"] → YES is first
        const prices = market.outcomePrices ? JSON.parse(market.outcomePrices) : null;
        const yes = prices ? Math.round(parseFloat(prices[0]) * 100) : null;
        if (yes !== null) results[m.id] = { yes, prev: POLY_MOCK[m.id]?.prev ?? yes, live: true };
      } catch { /* fall through to mock */ }
    });
    await Promise.allSettled(fetches);
  } catch { /* all failed */ }

  // Fill missing with mock data
  POLY_MARKETS.forEach(m => {
    if (!results[m.id]) results[m.id] = { ...POLY_MOCK[m.id], live: false };
  });
  return results;
}

// ── ODDS DISPLAY HELPERS ──────────────────────────────────
function oddsColor(pct) {
  if (pct >= 70) return C.green;
  if (pct >= 50) return C.gold2;
  if (pct >= 30) return C.orange;
  return C.red;
}

function OddsBar({ yes, prev, size = "normal" }) {
  const col = oddsColor(yes);
  const shift = yes - (prev ?? yes);
  const isLarge = size === "large";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
        <div style={{ flex: 1, height: isLarge ? 6 : 4, background: "rgba(0,0,0,.35)", borderRadius: 2, overflow: "hidden" }}>
          <div style={{ width: `${yes}%`, height: "100%", background: col, borderRadius: 2, transition: "width 1s ease" }} />
        </div>
        <span style={{ fontFamily: MONO, fontSize: isLarge ? 13 : 10, fontWeight: 700, color: col, minWidth: isLarge ? 36 : 28 }}>{yes}%</span>
        {shift !== 0 && (
          <span style={{ fontFamily: MONO, fontSize: 8, color: shift > 0 ? C.green : C.red, minWidth: 24 }}>
            {shift > 0 ? "↑" : "↓"}{Math.abs(shift)}
          </span>
        )}
      </div>
    </div>
  );
}

function PolyBadge({ yes }) {
  const col = oddsColor(yes);
  return (
    <span style={{ fontFamily: MONO, fontSize: 8, padding: "2px 6px", borderRadius: 2,
      background: `${col}18`, border: `1px solid ${col}40`, color: col, letterSpacing: "0.08em" }}>
      {yes}% YES
    </span>
  );
}


// ── SIMULATED SOCIAL FEED (fallback when APIs not configured) ──
const MOCK_SOCIAL=[
  {id:"s1",source:"twitter",handle:"whale_alert",icon:"🐋",color:"cyan",text:"🚨 $47,832,000 #BTC (571 BTC) transferred from unknown wallet to Binance",sentiment:0.2,score:3,assets:["BTC"],ts:new Date(Date.now()-120000).toISOString(),url:"#"},
  {id:"s2",source:"truth",handle:"realDonaldTrump",icon:"🇺🇸",color:"red",text:"Crypto is the future. America will be the crypto capital of the world. BITCOIN!",sentiment:0.95,score:9,assets:["BTC","ETH","SOL"],ts:new Date(Date.now()-480000).toISOString(),url:"#"},
  {id:"s3",source:"reddit",handle:"r/CryptoCurrency",icon:"🔺",color:"orange",text:"[Megathread] ETH breaking out — fundamentals finally catching up to price action. Accumulation zone held perfectly.",sentiment:0.78,score:7,assets:["ETH"],ts:new Date(Date.now()-900000).toISOString(),url:"#"},
  {id:"s4",source:"cryptopanic",handle:"CoinDesk",icon:"📰",color:"blue",text:"SEC drops lawsuit against Coinbase — landmark victory for crypto regulation clarity in the US",sentiment:0.88,score:8,assets:["BTC","ETH","COIN"],ts:new Date(Date.now()-1800000).toISOString(),url:"#"},
  {id:"s5",source:"twitter",handle:"lookonchain",icon:"🔍",color:"blue",text:"A whale just withdrew 12,500 $ETH ($19.9M) from Binance 30 mins ago. Same wallet bought before the last 40% rally.",sentiment:0.85,score:8,assets:["ETH"],ts:new Date(Date.now()-2400000).toISOString(),url:"#"},
  {id:"s6",source:"reddit",handle:"r/wallstreetbets",icon:"🦍",color:"orange",text:"NVDA earnings tomorrow — IV crush is real but calls printing. 10k shares at $103 here we go 🚀",sentiment:0.72,score:6,assets:["NVDA"],ts:new Date(Date.now()-3000000).toISOString(),url:"#"},
  {id:"s7",source:"twitter",handle:"tier10k",icon:"📊",color:"gold",text:"BTC dominance dropping while alts hold — this is the rotation. ETH/BTC pair looks ready. Alt season setup.",sentiment:0.82,score:8,assets:["BTC","ETH","SOL"],ts:new Date(Date.now()-3600000).toISOString(),url:"#"},
  {id:"s8",source:"truth",handle:"realDonaldTrump",icon:"🇺🇸",color:"red",text:"The failing Fed needs to CUT RATES NOW. The economy is strong but they are holding us back. Rate cuts immediately!",sentiment:0.7,score:7,assets:["XAU","BTC","EURUSD"],ts:new Date(Date.now()-5400000).toISOString(),url:"#"},
  {id:"s9",source:"cryptopanic",handle:"Reuters",icon:"📰",color:"blue",text:"Gold hits new record high as central banks accelerate purchases — WGC reports 300+ tonnes bought in Q1",sentiment:0.85,score:8,assets:["XAU","XAG"],ts:new Date(Date.now()-7200000).toISOString(),url:"#"},
  {id:"s10",source:"twitter",handle:"zerohedge",icon:"⚡",color:"orange",text:"BREAKING: US deficit hits $2.1T — dollar debasement accelerating. Real assets: gold, bitcoin, commodities.",sentiment:0.6,score:6,assets:["XAU","BTC"],ts:new Date(Date.now()-9000000).toISOString(),url:"#"},
  {id:"s11",source:"reddit",handle:"r/CryptoCurrency",icon:"🔺",color:"orange",text:"SOL network fees at all-time low while throughput hits record — this is the infrastructure that wins long term",sentiment:0.8,score:7,assets:["SOL"],ts:new Date(Date.now()-10800000).toISOString(),url:"#"},
  {id:"s12",source:"twitter",handle:"CryptoKaleo",icon:"🌊",color:"teal",text:"ETH setting up for a violent move. Hidden bullish divergence on 4h. $2,200 target if BTC holds $82k.",sentiment:0.88,score:8,assets:["ETH","BTC"],ts:new Date(Date.now()-12600000).toISOString(),url:"#"},
];

// ── SOCIAL API FETCHERS ────────────────────────────────────
async function fetchCryptoPanic(key){
  if(!key||key==="YOUR_CRYPTOPANIC_KEY_HERE")return null;
  try{
    const r=await fetch(`https://cryptopanic.com/api/v1/posts/?auth_token=${key}&filter=hot&public=true&kind=news`);
    if(!r.ok)return null;
    const d=await r.json();
    return(d.results||[]).slice(0,8).map(item=>({
      id:"cp-"+item.id,
      source:"cryptopanic",
      handle:item.source?.title||"CryptoPanic",
      icon:"📰",
      color:"blue",
      text:item.title,
      sentiment:item.votes?.positive>item.votes?.negative?0.7:0.3,
      score:Math.min(10,Math.round((item.votes?.positive||0)/5)+4),
      assets:(item.currencies||[]).map(c=>c.code).filter(c=>ALL_SYMS.includes(c)),
      ts:item.published_at,
      url:item.url,
    }));
  }catch{return null;}
}

async function fetchTwitterAccounts(rapidKey){
  if(!rapidKey||rapidKey==="YOUR_RAPIDAPI_KEY_HERE")return null;
  try{
    const results=await Promise.allSettled(
      TWITTER_ACCOUNTS.slice(0,3).map(async acc=>{
        const r=await fetch(`https://twitter135.p.rapidapi.com/v2/UserTweets/?id=${acc.handle}&count=3`,{headers:{"X-RapidAPI-Key":rapidKey,"X-RapidAPI-Host":"twitter135.p.rapidapi.com"}});
        if(!r.ok)return[];
        const d=await r.json();
        return(d.data?.timeline_v2?.timeline?.instructions||[]).flatMap(i=>i.entries||[]).filter(e=>e.content?.itemContent?.tweet_results?.result).slice(0,2).map(e=>{
          const t=e.content.itemContent.tweet_results.result.legacy;
          const mentionedAssets=ALL_SYMS.filter(sym=>t.full_text?.toUpperCase().includes(sym));
          return{id:"tw-"+t.id_str,source:"twitter",handle:acc.handle,label:acc.label,icon:acc.icon,color:acc.color,text:t.full_text,sentiment:t.favorite_count>500?0.75:0.5,score:Math.min(10,Math.round(t.favorite_count/1000)+4),assets:mentionedAssets,ts:t.created_at,url:`https://twitter.com/${acc.handle}/status/${t.id_str}`};
        });
      })
    );
    return results.flatMap(r=>r.status==="fulfilled"?r.value:[]);
  }catch{return null;}
}

async function fetchTruthSocial(){
  try{
    // Truth Social RSS via public endpoint
    const r=await fetch("https://truthsocial.com/@realDonaldTrump/feed.rss",{mode:"cors"});
    if(!r.ok)throw new Error("no rss");
    const text=await r.text();
    const parser=new DOMParser();
    const xml=parser.parseFromString(text,"application/xml");
    const items=[...xml.querySelectorAll("item")].slice(0,5);
    return items.map(item=>{
      const text=item.querySelector("description")?.textContent?.replace(/<[^>]+>/g,"").trim()||"";
      const assets=ALL_SYMS.filter(sym=>text.toUpperCase().includes(sym)||text.toUpperCase().includes(sym==="BTC"?"BITCOIN":sym==="ETH"?"ETHEREUM":sym==="XAU"?"GOLD":sym));
      const bullKeywords=["CRYPTO","BITCOIN","RATE CUT","ECONOMY STRONG","AMERICA","WIN","GREAT"];
      const bearKeywords=["TARIFF","CHINA","INFLATION","FAILING","DISASTER"];
      const bullScore=bullKeywords.filter(k=>text.toUpperCase().includes(k)).length;
      const bearScore=bearKeywords.filter(k=>text.toUpperCase().includes(k)).length;
      const sentiment=bullScore>bearScore?0.75:bearScore>bullScore?0.35:0.5;
      return{id:"ts-"+Math.random(),source:"truth",handle:"realDonaldTrump",icon:"🇺🇸",color:"red",text:text.slice(0,240),sentiment,score:Math.round(sentiment*10),assets:assets.length?assets:["BTC","XAU"],ts:item.querySelector("pubDate")?.textContent||new Date().toISOString(),url:item.querySelector("link")?.textContent||"https://truthsocial.com/@realDonaldTrump"};
    });
  }catch{return null;}
}

async function fetchReddit(){
  try{
    const subs=["CryptoCurrency","wallstreetbets"];
    const results=await Promise.all(subs.map(async sub=>{
      const r=await fetch(`https://www.reddit.com/r/${sub}/hot.json?limit=5`,{headers:{"User-Agent":"CLVRQuant/3.0"}});
      if(!r.ok)return[];
      const d=await r.json();
      return(d.data?.children||[]).slice(0,3).map(post=>{
        const p=post.data;
        const assets=ALL_SYMS.filter(sym=>p.title?.toUpperCase().includes(sym)||p.title?.toUpperCase().includes(sym==="BTC"?"BITCOIN":sym==="ETH"?"ETHEREUM":sym==="XAU"?"GOLD":sym==="NVDA"?"NVIDIA":sym));
        const upRatio=p.upvote_ratio||0.5;
        return{id:"rd-"+p.id,source:"reddit",handle:"r/"+sub,icon:sub==="wallstreetbets"?"🦍":"🔺",color:"orange",text:p.title,sentiment:upRatio,score:Math.min(10,Math.round(p.score/500)+3),assets:assets.length?assets:[],ts:new Date(p.created_utc*1000).toISOString(),url:"https://reddit.com"+p.permalink};
      });
    }));
    return results.flat();
  }catch{return null;}
}

// ── SENTIMENT SCORE COMPONENT ──────────────────────────────
function SentimentBar({score,color}){
  const c=score>=7?C.green:score>=5?C.orange:C.red;
  return(<div style={{display:"flex",alignItems:"center",gap:5}}>
    <div style={{width:48,height:4,background:"rgba(0,0,0,.3)",borderRadius:2,overflow:"hidden"}}>
      <div style={{width:`${score*10}%`,height:"100%",background:c,borderRadius:2,transition:"width .5s"}}/>
    </div>
    <span style={{fontFamily:MONO,fontSize:8,color:c,fontWeight:700,minWidth:12}}>{score}</span>
  </div>);
}

// ── SOURCE BADGE ──────────────────────────────────────────
function SourceIcon({source,color,icon}){
  const bg={twitter:"rgba(29,161,242,.12)",truth:"rgba(255,64,96,.12)",reddit:"rgba(255,140,0,.12)",cryptopanic:"rgba(59,130,246,.12)"}[source]||"rgba(74,93,128,.12)";
  const border={twitter:"rgba(29,161,242,.25)",truth:"rgba(255,64,96,.25)",reddit:"rgba(255,140,0,.25)",cryptopanic:"rgba(59,130,246,.25)"}[source]||"rgba(74,93,128,.25)";
  const label={twitter:"X",truth:"TRUTH",reddit:"REDDIT",cryptopanic:"NEWS"}[source]||"FEED";
  return(<span style={{fontFamily:MONO,fontSize:7,padding:"2px 5px",borderRadius:2,background:bg,border:`1px solid ${border}`,letterSpacing:"0.1em",color:{twitter:C.cyan,truth:C.red,reddit:C.orange,cryptopanic:C.blue}[source]||C.muted2,display:"inline-flex",alignItems:"center",gap:3}}>{icon} {label}</span>);
}

// ── SPARKLINE ─────────────────────────────────────────────
function Sparkline({data,color,width=80,height=22}){
  if(!data||data.length<2)return<span style={{fontSize:8,opacity:.3,color:C.muted}}>—</span>;
  const min=Math.min(...data),max=Math.max(...data),range=max-min||1;
  const pts=data.map((v,i)=>`${(i/(data.length-1))*width},${height-((v-min)/range)*(height-2)+1}`).join(" ");
  const up=data[data.length-1]>=data[0];
  return(<svg width={width} height={height} style={{overflow:"visible",flexShrink:0}}><polyline points={pts} fill="none" stroke={color||(up?C.green:C.red)} strokeWidth="1.5" strokeLinejoin="round" strokeLinecap="round"/><circle cx={width} cy={height-((data[data.length-1]-min)/range)*(height-2)+1} r="2.5" fill={color||(up?C.green:C.red)}/></svg>);
}

// ── PUSH NOTIFICATION ─────────────────────────────────────
async function sendPush(title,body,tag="cq"){
  if(!("Notification" in window))return;
  if(Notification.permission==="default")await Notification.requestPermission();
  if(Notification.permission==="granted")try{new Notification(title,{body,tag});}catch(e){}
}

// ── ALERT BANNER ──────────────────────────────────────────
function AlertBanner({alerts,onDismiss}){
  if(!alerts||alerts.length===0)return null;
  const a=alerts[0];
  const styles={macro:{bg:"rgba(255,140,0,.12)",border:"rgba(255,140,0,.35)",icon:"🏦",color:C.orange},volume:{bg:"rgba(0,212,255,.10)",border:"rgba(0,212,255,.35)",icon:"📊",color:C.cyan},funding:{bg:"rgba(0,199,135,.10)",border:"rgba(0,199,135,.35)",icon:"⚡",color:C.green},liq:{bg:"rgba(255,64,96,.10)",border:"rgba(255,64,96,.35)",icon:"💥",color:C.red},social:{bg:"rgba(168,85,247,.10)",border:"rgba(168,85,247,.35)",icon:"📡",color:C.purple},price:{bg:"rgba(201,168,76,.10)",border:"rgba(201,168,76,.35)",icon:"✦",color:C.gold}};
  const tc=styles[a.type]||styles.price;
  return(<div style={{position:"fixed",top:0,left:0,right:0,zIndex:200,padding:"0 12px",maxWidth:640,margin:"0 auto"}}><div style={{background:tc.bg,border:`1px solid ${tc.border}`,borderTop:"none",borderRadius:"0 0 6px 6px",padding:"10px 14px",backdropFilter:"blur(16px)"}}><div style={{display:"flex",alignItems:"flex-start",gap:10}}><span style={{fontSize:16,flexShrink:0,marginTop:1}}>{tc.icon}</span><div style={{flex:1}}><div style={{fontFamily:MONO,fontSize:9,fontWeight:700,color:tc.color,letterSpacing:"0.18em",textTransform:"uppercase",marginBottom:3}}>{a.title}</div><div style={{fontFamily:SANS,fontSize:11,color:C.text,lineHeight:1.6}}>{a.body}</div>{a.assets&&a.assets.length>0&&<div style={{display:"flex",gap:4,marginTop:5,flexWrap:"wrap"}}>{a.assets.map(sym=><span key={sym} style={{fontFamily:MONO,fontSize:8,color:tc.color,background:tc.bg,border:`1px solid ${tc.border}`,borderRadius:2,padding:"1px 6px"}}>{sym}</span>)}</div>}</div><button onClick={()=>onDismiss(a.id)} style={{background:"none",border:"none",color:C.muted2,fontSize:18,cursor:"pointer",flexShrink:0,padding:0,lineHeight:1}}>×</button></div>{alerts.length>1&&<div style={{fontFamily:MONO,fontSize:7,color:C.muted,marginTop:4,letterSpacing:"0.12em"}}>{alerts.length-1} more alert{alerts.length>2?"s":""}</div>}</div></div>);
}

// ── COUNTDOWN ─────────────────────────────────────────────
function Countdown({dateStr,timeET,compact=false}){
  const[diff,setDiff]=useState(null);
  useEffect(()=>{const calc=()=>{const[h,m]=timeET.split(":").map(Number);const[y,mo,d]=dateStr.split("-").map(Number);setDiff(new Date(Date.UTC(y,mo-1,d,h+5,m,0))-new Date());};calc();const iv=setInterval(calc,1000);return()=>clearInterval(iv);},[dateStr,timeET]);
  if(diff===null)return null;
  if(diff<0)return<span style={{fontFamily:MONO,fontSize:compact?7:8,color:C.muted}}>PAST</span>;
  const s=Math.floor(diff/1000);const dd=Math.floor(s/86400);const h=Math.floor((s%86400)/3600);const min=Math.floor((s%3600)/60);const sec=s%60;
  const isHot=diff<30*60*1000;const col=isHot?C.red:diff<2*60*60*1000?C.orange:C.muted2;
  if(compact){return<span style={{fontFamily:MONO,fontSize:8,color:col,fontWeight:isHot?700:400}}>{dd>0?`${dd}d ${h}h`:h>0?`${h}h ${min}m`:`${min}m ${sec}s`}</span>;}
  return(<div style={{display:"flex",gap:6,alignItems:"center"}}>
    {dd>0&&<div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{dd}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted}}>DAYS</div></div>}
    <div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{String(h).padStart(2,"0")}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted}}>HRS</div></div>
    <div style={{fontFamily:MONO,color:col,fontSize:16,marginBottom:10}}>:</div>
    <div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{String(min).padStart(2,"0")}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted}}>MIN</div></div>
    {dd===0&&<><div style={{fontFamily:MONO,color:col,fontSize:16,marginBottom:10}}>:</div><div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:col,lineHeight:1}}>{String(sec).padStart(2,"0")}</div><div style={{fontFamily:MONO,fontSize:6,color:C.muted}}>SEC</div></div></>}
  </div>);
}

// ── LIQ HEATMAP ───────────────────────────────────────────
function LiqHeatmap({sym,price}){
  if(!price)return null;
  const step=sym==="BTC"?500:sym==="ETH"?50:sym==="SOL"?5:sym==="XAU"?20:null;
  if(!step)return null;
  const seed=Math.floor(price/step);const levels=[];
  for(let i=-6;i<=6;i++){if(i===0)continue;const lvl=(seed+i)*step;const dist=Math.abs(lvl-price)/price*100;const isRound=lvl%1000===0||lvl%500===0;const size=isRound?Math.floor(180+Math.random()*220):Math.floor(20+Math.random()*100);if(dist>0.1&&dist<6)levels.push({price:lvl,size,side:i<0?"long":"short"});}
  levels.sort((a,b)=>a.price-b.price);
  const above=levels.filter(l=>l.price>price).slice(0,4).reverse();
  const below=levels.filter(l=>l.price<price).reverse().slice(0,4);
  const maxSize=Math.max(...levels.map(l=>l.size),1);
  return(<div>
    {above.reverse().map(l=>(<div key={l.price} style={{display:"flex",alignItems:"center",gap:6,marginBottom:3}}><div style={{fontFamily:MONO,fontSize:8,color:C.red,width:62,textAlign:"right"}}>{fmt(l.price,sym)}</div><div style={{flex:1,position:"relative",height:12,background:"rgba(255,64,96,.06)",borderRadius:1}}><div style={{position:"absolute",right:0,top:0,bottom:0,width:`${(l.size/maxSize)*100}%`,background:`rgba(255,64,96,${0.15+l.size/maxSize*0.45})`,borderRadius:1}}/></div><div style={{fontFamily:MONO,fontSize:7,color:C.muted2,width:38}}>${l.size}M</div></div>))}
    <div style={{display:"flex",alignItems:"center",gap:6,marginBottom:3,marginTop:2}}><div style={{fontFamily:MONO,fontSize:9,color:C.gold,width:62,textAlign:"right",fontWeight:700}}>{fmt(price,sym)}</div><div style={{flex:1,height:1,background:`linear-gradient(90deg,${C.gold},transparent)`}}/><div style={{fontFamily:MONO,fontSize:7,color:C.gold,width:38}}>NOW</div></div>
    {below.map(l=>(<div key={l.price} style={{display:"flex",alignItems:"center",gap:6,marginBottom:3}}><div style={{fontFamily:MONO,fontSize:8,color:C.green,width:62,textAlign:"right"}}>{fmt(l.price,sym)}</div><div style={{flex:1,position:"relative",height:12,background:"rgba(0,199,135,.06)",borderRadius:1}}><div style={{position:"absolute",left:0,top:0,bottom:0,width:`${(l.size/maxSize)*100}%`,background:`rgba(0,199,135,${0.15+l.size/maxSize*0.45})`,borderRadius:1}}/></div><div style={{fontFamily:MONO,fontSize:7,color:C.muted2,width:38}}>${l.size}M</div></div>))}
    <div style={{display:"flex",justifyContent:"space-between",marginTop:8,paddingTop:6,borderTop:`1px solid ${C.border}`}}><div style={{fontFamily:MONO,fontSize:7,color:C.green}}>▲ LONG LIQDS BELOW</div><div style={{fontFamily:MONO,fontSize:7,color:C.red}}>SHORT LIQDS ABOVE ▼</div></div>
  </div>);
}

// ── TOAST ─────────────────────────────────────────────────
function Toast({msg,onDone}){useEffect(()=>{const t=setTimeout(onDone,3500);return()=>clearTimeout(t);},[onDone]);return(<div style={{position:"fixed",bottom:88,left:"50%",transform:"translateX(-50%)",background:C.gold,color:C.bg,borderRadius:2,padding:"10px 20px",fontSize:10,fontWeight:700,fontFamily:MONO,zIndex:9999,letterSpacing:"0.1em",boxShadow:`0 4px 24px rgba(201,168,76,.5)`,whiteSpace:"nowrap"}}>{msg}</div>);}

// ── PRICE APIs ────────────────────────────────────────────
async function fetchHyperliquid(){
  const[r1,r2]=await Promise.all([fetch("https://api.hyperliquid.xyz/info",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"allMids"})}),fetch("https://api.hyperliquid.xyz/info",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({type:"metaAndAssetCtxs"})})]);
  const mids=await r1.json(),meta=await r2.json();
  const funding={};
  meta[0].universe.forEach((asset,i)=>{if(CRYPTO_SYMS.includes(asset.name))funding[asset.name]={funding:+(parseFloat(meta[1][i]?.funding||0)*100).toFixed(4),oi:parseFloat(meta[1][i]?.openInterest||0)*parseFloat(meta[1][i]?.markPx||0),volume:parseFloat(meta[1][i]?.dayNtlVlm||0)};});
  const result={};
  CRYPTO_SYMS.forEach(sym=>{if(mids[sym]){const price=parseFloat(mids[sym]);result[sym]={price,chg:+((price-CRYPTO_BASE[sym])/CRYPTO_BASE[sym]*100).toFixed(2),funding:funding[sym]?.funding||0,oi:funding[sym]?.oi||0,volume:funding[sym]?.volume||0,live:true};}});
  return result;
}
async function fhQuote(sym){const r=await fetch(`https://finnhub.io/api/v1/quote?symbol=${sym}&token=${FINNHUB_KEY}`);if(!r.ok)throw new Error(`FH ${r.status}`);const d=await r.json();if(!d||!d.c||d.c===0)throw new Error("zero");return{price:d.c,chg:d.dp??(d.pc?(d.c-d.pc)/d.pc*100:0),live:true};}
async function fetchFinnhub(){
  const stocks={},metals={},forex={};
  await Promise.allSettled([...EQUITY_SYMS.map(async sym=>{try{stocks[sym]=await fhQuote(sym);}catch{stocks[sym]={price:EQUITY_BASE[sym],chg:0,live:false};}}),...Object.entries(FH_METALS).map(async([sym,fh])=>{try{metals[sym]=await fhQuote(fh);}catch{metals[sym]={price:METALS_BASE[sym],chg:0,live:false};}}),...Object.entries(FH_FOREX).map(async([sym,fh])=>{try{forex[sym]=await fhQuote(fh);}catch{forex[sym]={price:FOREX_BASE[sym],chg:0,live:false};}})]);
  return{stocks,metals,forex};
}

// ═══════════════════════════════════════════════════════════
// MAIN APP
// ═══════════════════════════════════════════════════════════
export default function App(){
  const[tab,setTab]=useState("radar");
  const[priceTab,setPriceTab]=useState("crypto");
  const[sigSubTab,setSigSubTab]=useState("all");
  const[socialFilter,setSocialFilter]=useState("all");
  const[macroFilter,setMacroFilter]=useState("ALL");
  const[liqSym,setLiqSym]=useState("BTC");
  const[notifPerm,setNotifPerm]=useState(typeof Notification!=="undefined"?Notification.permission:"default");

  // prices
  const[cryptoPrices,setCryptoPrices]=useState(()=>Object.fromEntries(CRYPTO_SYMS.map(k=>[k,{price:CRYPTO_BASE[k],chg:0,funding:0,oi:0,volume:0,live:false,oiHistory:[],volHistory:[],fundHistory:[]}])));
  const[equityPrices,setEquityPrices]=useState(()=>Object.fromEntries(EQUITY_SYMS.map(k=>[k,{price:EQUITY_BASE[k],chg:0,live:false}])));
  const[metalPrices,setMetalPrices]=useState(()=>Object.fromEntries(METALS_SYMS.map(k=>[k,{price:METALS_BASE[k],chg:0,live:false}])));
  const[forexPrices,setForexPrices]=useState(()=>Object.fromEntries(FOREX_SYMS.map(k=>[k,{price:FOREX_BASE[k],chg:0,live:false}])));
  const[flashes,setFlashes]=useState({});
  const prevRef=useRef({});
  const volRef=useRef({});
  const fundRef=useRef({});

  // social
  const[socialFeed,setSocialFeed]=useState(MOCK_SOCIAL);
  const[socialLoading,setSocialLoading]=useState(false);
  const[socialLastFetch,setSocialLastFetch]=useState(null);
  const[overallSentiment,setOverallSentiment]=useState({score:6.8,label:"BULLISH",bias:"RISK ON"});
  const seenSocialIds=useRef(new Set(MOCK_SOCIAL.map(s=>s.id)));

  const[watchlist,setWatchlist]=useState(["BTC","ETH","SOL","XAU","TSLA"]);
  const[signals,setSignals]=useState(SIGNALS_POOL.slice(0,8).map((s,i)=>({...s,time:`${i*4+2}m ago`,id:i})));
  const[flashSigId,setFlashSigId]=useState(null);
  const[sigCount,setSigCount]=useState(44);
  const[tick,setTick]=useState(0);
  const[lastUpdate,setLastUpdate]=useState(new Date());
  const[hlStatus,setHlStatus]=useState("connecting");
  const[fhStatus,setFhStatus]=useState("connecting");
  const[toast,setToast]=useState(null);
  const[aiInput,setAiInput]=useState("");
  const[aiOutput,setAiOutput]=useState("");
  const[aiLoading,setAiLoading]=useState(false);
  const idRef=useRef(300);
  const firedAlerts=useRef(new Set());
  const macroFired=useRef(new Set());
  const[activeAlerts,setActiveAlerts]=useState([]);
  // Polymarket state
  const[polyOdds,setPolyOdds]=useState(()=>Object.fromEntries(POLY_MARKETS.map(m=>[m.id,{...POLY_MOCK[m.id],live:false}])));
  const[polyLoading,setPolyLoading]=useState(false);
  const[polyLastFetch,setPolyLastFetch]=useState(null);
  const[polyCat,setPolyCat]=useState("all");
  const prevPolyRef=useRef({});

    const[briefLoading,setBriefLoading]=useState(false);
  const[briefData,setBriefData]=useState(null);
  const[briefDate,setBriefDate]=useState(null);
  const[subEmail,setSubEmail]=useState("");
  const[subLoading,setSubLoading]=useState(false);

  // ── ALERT SYSTEM ────────────────────────────────────────
  const addAlert=useCallback((alert)=>{
    const key=alert.id||alert.title;
    if(firedAlerts.current.has(key))return;
    firedAlerts.current.add(key);
    setActiveAlerts(prev=>[{...alert,id:key,ts:Date.now()},...prev.slice(0,4)]);
    sendPush(alert.title,alert.body,key);
    setToast(`🔔 ${alert.title}`);
  },[]);
  const dismissAlert=(id)=>setActiveAlerts(prev=>prev.filter(a=>a.id!==id));

  // ── SOCIAL SENTIMENT CALC ────────────────────────────────
  const calcSentiment=useCallback((feed)=>{
    if(!feed.length)return;
    const recent=feed.slice(0,20);
    const avg=recent.reduce((a,b)=>a+b.score,0)/recent.length;
    const label=avg>=7?"VERY BULLISH":avg>=6?"BULLISH":avg>=5?"NEUTRAL":avg>=4?"BEARISH":"VERY BEARISH";
    const bias=avg>=6.5?"RISK ON":avg>=5?"NEUTRAL":"RISK OFF";
    setOverallSentiment({score:+avg.toFixed(1),label,bias});
  },[]);

  // ── SOCIAL ALERT DETECTION ───────────────────────────────
  const checkSocialAlert=useCallback((item)=>{
    if(seenSocialIds.current.has(item.id))return;
    seenSocialIds.current.add(item.id);
    const isHigh=item.score>=8;
    const isTrump=item.source==="truth";
    const isWhale=item.source==="twitter"&&item.handle==="whale_alert";
    if(isHigh||isTrump||isWhale){
      const watchedAssets=item.assets?.filter(a=>watchlist.includes(a))||[];
      if(watchedAssets.length>0||isTrump){
        addAlert({type:"social",title:`📡 ${isTrump?"TRUMP POST":isWhale?"WHALE ALERT":item.handle} · Score ${item.score}/10`,body:item.text.slice(0,160)+(item.text.length>160?"…":""),assets:item.assets?.slice(0,5)||[],id:`social-${item.id}`});
      }
    }
  },[addAlert,watchlist]);

  // ── SOCIAL FETCH ─────────────────────────────────────────
  const fetchSocial=useCallback(async()=>{
    setSocialLoading(true);
    const results=await Promise.allSettled([fetchCryptoPanic(CRYPTOPANIC_KEY),fetchTwitterAccounts(RAPIDAPI_KEY),fetchTruthSocial(),fetchReddit()]);
    const live=results.flatMap(r=>r.status==="fulfilled"&&r.value?r.value:[]);
    if(live.length>0){
      const merged=[...live,...MOCK_SOCIAL].filter((item,i,arr)=>arr.findIndex(x=>x.id===item.id)===i).sort((a,b)=>new Date(b.ts)-new Date(a.ts)).slice(0,30);
      setSocialFeed(merged);
      live.forEach(item=>checkSocialAlert(item));
      calcSentiment(merged);
      setSocialLastFetch(new Date());
    }else{
      calcSentiment(MOCK_SOCIAL);
    }
    setSocialLoading(false);
  },[checkSocialAlert,calcSentiment]);

  useEffect(()=>{fetchSocial();const iv=setInterval(fetchSocial,120000);return()=>clearInterval(iv);},[fetchSocial]);

  // ── POLYMARKET FETCH + ODDS SHIFT ALERTS ──────────────────
  const doPolyFetch = useCallback(async () => {
    setPolyLoading(true);
    try {
      const odds = await fetchPolymarket();
      // Check for >10% shift on any market
      POLY_MARKETS.forEach(m => {
        const prev = prevPolyRef.current[m.id];
        const curr = odds[m.id];
        if (prev && curr) {
          const shift = Math.abs(curr.yes - prev.yes);
          if (shift >= 10) {
            const dir = curr.yes > prev.yes ? "▲ SURGING" : "▼ COLLAPSING";
            addAlert({
              type: "social",
              title: `📊 POLYMARKET SHIFT · ${m.label}`,
              body: `Odds moved ${shift}% in <1h — now ${curr.yes}% YES ${dir}. Strong signal for ${m.assets?.join(", ")}.`,
              assets: m.assets,
              id: `poly-shift-${m.id}-${Math.floor(Date.now()/3600000)}`,
            });
          }
        }
        prevPolyRef.current[m.id] = curr;
      });
      setPolyOdds(odds);
      setPolyLastFetch(new Date());
    } catch(e) { console.error("Poly fetch error", e); }
    setPolyLoading(false);
  }, [addAlert]);

  useEffect(() => {
    doPolyFetch();
    const iv = setInterval(doPolyFetch, 60000); // refresh every 60s
    return () => clearInterval(iv);
  }, [doPolyFetch]);

  // ── FLASH ────────────────────────────────────────────────
  const triggerFlashes=useCallback((updates)=>{
    const nF={};Object.entries(updates).forEach(([sym,d])=>{const prev=prevRef.current[sym];if(prev&&d.price&&d.price!==prev)nF[sym]=d.price>prev?"green":"red";if(d.price)prevRef.current[sym]=d.price;});
    if(Object.keys(nF).length){setFlashes(f=>({...f,...nF}));setTimeout(()=>setFlashes(f=>{const n={...f};Object.keys(nF).forEach(k=>delete n[k]);return n;}),700);}
  },[]);

  // ── DETECTION ENGINES ────────────────────────────────────
  const checkVolumeSpike=useCallback((sym,vol)=>{
    const hist=volRef.current[sym]||[];
    if(hist.length>=5){const avg=hist.slice(-5).reduce((a,b)=>a+b,0)/5;if(avg>0&&vol>avg*5)addAlert({type:"volume",title:`VOLUME SPIKE · ${sym}`,body:`${sym} volume ${(vol/avg).toFixed(1)}× average. Macro or whale-driven move likely.`,assets:[sym],id:`vol-${sym}-${Math.floor(Date.now()/300000)}`});}
    volRef.current[sym]=[...hist,vol].slice(-20);
  },[addAlert]);

  const checkFundingFlip=useCallback((sym,f)=>{
    const hist=fundRef.current[sym]||[];
    if(hist.length>=3){const p3=hist.slice(-3);if(p3.every(x=>x<0)&&f>0.01)addAlert({type:"funding",title:`FUNDING FLIP BULLISH · ${sym}`,body:`${sym} funding flipped from negative to +${f.toFixed(4)}%/8h. Squeeze setup forming.`,assets:[sym],id:`fund-bull-${sym}-${Math.floor(Date.now()/3600000)}`});else if(p3.every(x=>x>0)&&f<-0.01)addAlert({type:"funding",title:`FUNDING FLIP BEARISH · ${sym}`,body:`${sym} funding turned negative. Overleveraged longs at risk.`,assets:[sym],id:`fund-bear-${sym}-${Math.floor(Date.now()/3600000)}`});else if(Math.abs(f)>0.08)addAlert({type:"funding",title:`EXTREME FUNDING · ${sym}`,body:`${sym} funding at ${pct(f,4)}/8h — contrarian reversal signal.`,assets:[sym],id:`fund-ext-${sym}-${Math.floor(Date.now()/3600000)}`});}
    fundRef.current[sym]=[...hist,f].slice(-10);
  },[addAlert]);

  const checkMacroCountdowns=useCallback(()=>{
    const now=new Date();
    MACRO_EVENTS.forEach(evt=>{
      const[h,m]=evt.timeET.split(":").map(Number);const[y,mo,d]=evt.date.split("-").map(Number);
      const target=new Date(Date.UTC(y,mo-1,d,h+5,m,0));const diffMin=(target-now)/60000;
      [60,30,10,2].forEach(threshold=>{const key=`macro-${evt.id}-${threshold}`;if(!macroFired.current.has(key)&&diffMin<=threshold&&diffMin>threshold-0.6){macroFired.current.add(key);const urg=threshold<=10?"🚨":threshold<=30?"⚠️":"📅";addAlert({type:"macro",title:`${urg} ${evt.bank}: ${evt.name} in ${threshold}min`,body:`${evt.assets?.join(", ")} expected ~${evt.expectedMove}% move. Forecast: ${evt.forecast}. Position now.`,assets:evt.assets,id:key});}});
    });
  },[addAlert]);

  // ── HL FETCH ─────────────────────────────────────────────
  const doHL=useCallback(async()=>{
    try{const data=await fetchHyperliquid();setCryptoPrices(prev=>{const next={...prev};Object.entries(data).forEach(([sym,d])=>{const oiH=[...(prev[sym]?.oiHistory||[]),d.oi].slice(-20);const vH=[...(prev[sym]?.volHistory||[]),d.volume].slice(-20);const fH=[...(prev[sym]?.fundHistory||[]),d.funding].slice(-20);next[sym]={...prev[sym],...d,oiHistory:oiH,volHistory:vH,fundHistory:fH};if(d.volume>0)checkVolumeSpike(sym,d.volume);checkFundingFlip(sym,d.funding);});triggerFlashes(next);return next;});setHlStatus("live");}catch{setHlStatus("error");}
  },[triggerFlashes,checkVolumeSpike,checkFundingFlip]);
  useEffect(()=>{doHL();const iv=setInterval(doHL,3000);return()=>clearInterval(iv);},[doHL]);

  const doFH=useCallback(async()=>{
    try{const{stocks,metals,forex}=await fetchFinnhub();setEquityPrices(prev=>{const n={...prev,...stocks};triggerFlashes(n);return n;});setMetalPrices(prev=>{const n={...prev,...metals};triggerFlashes(n);return n;});setForexPrices(prev=>{const n={...prev,...forex};triggerFlashes(n);return n;});setFhStatus([...Object.values(stocks),...Object.values(metals),...Object.values(forex)].some(p=>p.live)?"live":"closed");}catch{setFhStatus("error");}
  },[triggerFlashes]);
  useEffect(()=>{doFH();const iv=setInterval(doFH,15000);return()=>clearInterval(iv);},[doFH]);

  const allPrices={...cryptoPrices,...equityPrices,...metalPrices,...forexPrices};

  // ── 1s TICK ──────────────────────────────────────────────
  useEffect(()=>{
    const iv=setInterval(()=>{setTick(t=>t+1);setLastUpdate(new Date());checkMacroCountdowns();if(tick%22===0){const s=SIGNALS_POOL[rndInt(0,SIGNALS_POOL.length-1)];const ns={...s,time:"just now",id:idRef.current++};setSignals(prev=>[ns,...prev.slice(0,11)]);setSigCount(c=>c+1);setFlashSigId(ns.id);setTimeout(()=>setFlashSigId(null),3000);}},1000);
    return()=>clearInterval(iv);
  },[tick,checkMacroCountdowns]);

  const toggleWatch=sym=>{const has=watchlist.includes(sym);setWatchlist(prev=>has?prev.filter(s=>s!==sym):[...prev,sym]);setToast(has?`Removed ${sym}`:`${sym} added ✦`);};
  const isWatched=sym=>watchlist.includes(sym);
  const shareSignal=sig=>{navigator.clipboard.writeText(`✦ CLVRQuant SIGNAL\n${sig.icon} ${sig.token} ${sig.dir} | Conf:${sig.conf} | ${sig.lev}\n${sig.desc}`).then(()=>setToast("Signal copied ✦"));};
  const requestPush=async()=>{if(!("Notification" in window)){setToast("Notifications not supported");return;}const p=await Notification.requestPermission();setNotifPerm(p);if(p==="granted")setToast("✦ Push notifications enabled!");else setToast("Blocked in browser settings");};

  // ── SOCIAL CONTEXT FOR AI ────────────────────────────────
  const buildPolyContext = () => {
    const highlights = POLY_MARKETS.filter(m => polyOdds[m.id]).slice(0, 8);
    if (!highlights.length) return "";
    return "\n\nPOLYMARKET PREDICTION ODDS (real-money markets):\n" +
      highlights.map(m => {
        const o = polyOdds[m.id];
        const shift = o.yes - (o.prev ?? o.yes);
        return `[${m.cat.toUpperCase()}] ${m.label}: ${o.yes}% YES${shift !== 0 ? ` (${shift > 0 ? "+" : ""}${shift}% shift)` : ""}`;
      }).join("\n") +
      "\n\nHigh odds = market expects event likely. Rapid shifts = smart-money signal.";
  };

    const buildSocialContext=()=>{
    const recent=socialFeed.slice(0,6);
    if(!recent.length)return"";
    return"\n\nSOCIAL INTELLIGENCE:\n"+recent.map(s=>`[${s.source.toUpperCase()}·${s.handle}·Score:${s.score}/10] ${s.text.slice(0,120)}`).join("\n")+`\n\nOVERALL MARKET SENTIMENT: ${overallSentiment.label} (${overallSentiment.score}/10) · ${overallSentiment.bias}`;
  };

  const generateBrief=async()=>{
    if(ANTHROPIC_KEY==="YOUR_ANTHROPIC_KEY_HERE"){setToast("Add Anthropic key");return;}
    setBriefLoading(true);
    const btc=cryptoPrices["BTC"],eth=cryptoPrices["ETH"],sol=cryptoPrices["SOL"],xau=metalPrices["XAU"],eurusd=forexPrices["EURUSD"],usdjpy=forexPrices["USDJPY"],usdcad=forexPrices["USDCAD"];
    const today=new Date().toLocaleDateString("en-US",{weekday:"long",year:"numeric",month:"long",day:"numeric"});
    const socialCtx=buildSocialContext();const polyCtx=buildPolyContext();
    try{const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","anthropic-version":"2023-06-01","x-api-key":ANTHROPIC_KEY},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:900,messages:[{role:"user",content:`Brief for ${today}. PRICES: BTC:${fmt(btc?.price,"BTC")}(${pct(btc?.chg)}) ETH:${fmt(eth?.price,"ETH")}(${pct(eth?.chg)}) SOL:${fmt(sol?.price,"SOL")} XAU:${fmt(xau?.price,"XAU")} EURUSD:${fmt(eurusd?.price,"EURUSD")} USDJPY:${fmt(usdjpy?.price,"USDJPY")}.${socialCtx}${polyCtx}\n\nWrite JSON only: {"headline":"s","bias":"RISK ON|RISK OFF|NEUTRAL","btc":"s","eth":"s","sol":"s","xau":"s","xag":"s","eurusd":"s","usdjpy":"s","usdcad":"s","watchToday":["s","s","s","s","s"],"keyRisk":"s","socialSentiment":"s"}`}]}));const data=await res.json();setBriefData(JSON.parse((data.content||[]).map(b=>b.text||"").join("").replace(/```json|```/g,"").trim()));setBriefDate(today);}catch{setToast("Brief failed.");}
    setBriefLoading(false);
  };

  const runAI=async()=>{
    if(!aiInput.trim()||aiLoading)return;setAiLoading(true);setAiOutput("");
    const snap=(sym,p)=>{const d=p[sym];return d?`${fmt(d.price,sym)}(${pct(d.chg)})${d.live?"✅":"~"}`:"—";};
    const socialCtx=buildSocialContext();
    const polyCtx=buildPolyContext();
    const sys=`You are CLVRQuant elite trading AI. CRYPTO:${CRYPTO_SYMS.slice(0,5).map(s=>`${s}:${snap(s,cryptoPrices)}${cryptoPrices[s]?.funding?`F:${pct(cryptoPrices[s].funding,4)}/8h`:""}`).join("|")} STOCKS:${EQUITY_SYMS.slice(0,4).map(s=>`${s}:${snap(s,equityPrices)}`).join("|")} METALS:XAU:${snap("XAU",metalPrices)} FOREX:${FOREX_SYMS.slice(0,4).map(s=>`${s}:${snap(s,forexPrices)}`).join("|")}${socialCtx}${polyCtx}\n\nGive: DIRECTION/ENTRY/STOP/TP1/TP2/LEVERAGE/CONVICTION/REASON (include social sentiment if relevant). No disclaimers.`;
    try{const res=await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json","anthropic-version":"2023-06-01","x-api-key":ANTHROPIC_KEY},body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:600,system:sys,messages:[{role:"user",content:aiInput}]})});if(!res.ok){const e=await res.text();setAiOutput(`Error ${res.status}: ${e}`);setAiLoading(false);return;}const data=await res.json();setAiOutput((data.content||[]).map(b=>b.text||"").join("")||"No response.");}catch(e){setAiOutput(`Error: ${e.message}`);}
    setAiLoading(false);
  };

  // ── STYLE HELPERS ────────────────────────────────────────
  const Badge=({label,color="gold",style={}})=>{const map={gold:{bg:"rgba(201,168,76,.1)",color:C.gold,border:"rgba(201,168,76,.25)"},green:{bg:"rgba(0,199,135,.1)",color:C.green,border:"rgba(0,199,135,.25)"},red:{bg:"rgba(255,64,96,.1)",color:C.red,border:"rgba(255,64,96,.25)"},orange:{bg:"rgba(255,140,0,.1)",color:C.orange,border:"rgba(255,140,0,.25)"},cyan:{bg:"rgba(0,212,255,.1)",color:C.cyan,border:"rgba(0,212,255,.25)"},blue:{bg:"rgba(59,130,246,.1)",color:C.blue,border:"rgba(59,130,246,.25)"},teal:{bg:"rgba(20,184,166,.1)",color:C.teal,border:"rgba(20,184,166,.25)"},pink:{bg:"rgba(236,72,153,.1)",color:C.pink,border:"rgba(236,72,153,.25)"},purple:{bg:"rgba(168,85,247,.1)",color:C.purple,border:"rgba(168,85,247,.25)"},muted:{bg:"rgba(74,93,128,.1)",color:C.muted2,border:"rgba(74,93,128,.25)"}};const t=map[color]||map.gold;return<span style={{fontSize:8,padding:"2px 7px",borderRadius:2,background:t.bg,color:t.color,border:`1px solid ${t.border}`,fontFamily:MONO,letterSpacing:"0.15em",textTransform:"uppercase",fontWeight:600,...style}}>{label}</span>;};
  const panel={background:C.panel,border:`1px solid ${C.border}`,borderRadius:2,overflow:"hidden",marginBottom:10};
  const ph={display:"flex",alignItems:"center",justifyContent:"space-between",padding:"11px 14px",borderBottom:`1px solid ${C.border}`,background:"rgba(201,168,76,.03)"};
  const PTitle=({children})=><span style={{fontFamily:SERIF,fontWeight:700,fontSize:13,color:C.white}}>{children}</span>;
  const SLabel=({children})=><div style={{fontFamily:MONO,fontSize:8,letterSpacing:"0.28em",textTransform:"uppercase",color:C.gold,marginBottom:12,display:"flex",alignItems:"center",gap:10}}><span style={{flex:"0 0 24px",height:1,background:`linear-gradient(90deg,${C.gold},transparent)`,display:"inline-block"}}/>{children}</div>;
  const SubBtn=({k,label,col="gold",state,setter})=>{const active=state===k;const ac=col==="green"?C.green:col==="blue"?C.blue:col==="teal"?C.teal:col==="red"?C.red:col==="purple"?C.purple:col==="cyan"?C.cyan:col==="orange"?C.orange:C.gold;return<button onClick={()=>setter(k)} style={{padding:"5px 11px",borderRadius:2,whiteSpace:"nowrap",outline:"none",cursor:"pointer",fontFamily:MONO,fontSize:8,letterSpacing:"0.12em",textTransform:"uppercase",border:`1px solid ${active?ac:C.border}`,background:active?"rgba(201,168,76,.07)":C.panel,color:active?ac:C.muted2,transition:"all .2s"}}>{label}</button>;};
  const LiveDot=({live})=><div style={{width:5,height:5,borderRadius:"50%",flexShrink:0,background:live?C.green:C.orange,boxShadow:live?`0 0 6px ${C.green}`:"none"}}/>;
  const PriceRow=({sym,d,extra})=>{if(!d)return null;const flash=flashes[sym];const isUp=Number(d.chg)>=0;return(<div style={{padding:"11px 14px",borderBottom:`1px solid ${C.border}`,transition:"background .35s",background:flash==="green"?"rgba(0,199,135,.05)":flash==="red"?"rgba(255,64,96,.05)":"transparent",display:"grid",gridTemplateColumns:"1fr auto auto auto",gap:8,alignItems:"center"}}><div><div style={{display:"flex",alignItems:"center",gap:7}}><span style={{fontFamily:MONO,fontWeight:600,fontSize:12,color:C.text}}>{sym}</span><button onClick={()=>toggleWatch(sym)} style={{background:"none",border:"none",cursor:"pointer",padding:0,fontSize:11,color:isWatched(sym)?C.gold:C.muted,opacity:isWatched(sym)?1:.3}}>✦</button></div>{extra&&<div style={{fontFamily:MONO,fontSize:8,color:C.muted,marginTop:2}}>{extra}</div>}</div><div style={{fontFamily:MONO,fontSize:13,fontWeight:600,color:flash==="green"?C.green:flash==="red"?C.red:C.white,transition:"color .35s"}}>{fmt(d.price,sym)}</div><div style={{fontFamily:MONO,fontSize:10,color:isUp?C.green:C.red,minWidth:50,textAlign:"right"}}>{pct(d.chg)}</div>{d.live?<Badge label="LIVE" color="green"/>:<Badge label="SIM" color="orange"/>}</div>);};
  const SignalRow=({sig})=>(<div style={{padding:"12px 14px",borderBottom:`1px solid ${C.border}`,background:flashSigId===sig.id?"rgba(201,168,76,.03)":"transparent",transition:"background .5s"}}><div style={{display:"grid",gridTemplateColumns:"28px 1fr auto",gap:10,alignItems:"start"}}><div onClick={()=>{setAiInput(`Analyze: ${sig.token} ${sig.dir} — ${sig.desc}`);setTab("ai");}} style={{width:26,height:26,borderRadius:2,display:"flex",alignItems:"center",justifyContent:"center",fontSize:13,cursor:"pointer",background:sig.dir==="LONG"?"rgba(0,199,135,.08)":"rgba(255,64,96,.08)",border:`1px solid ${sig.dir==="LONG"?"rgba(0,199,135,.2)":"rgba(255,64,96,.2)"}`}}>{sig.icon}</div><div onClick={()=>{setAiInput(`Analyze: ${sig.token} ${sig.dir} — ${sig.desc}`);setTab("ai");}} style={{cursor:"pointer"}}><div style={{fontFamily:MONO,fontWeight:600,fontSize:11,display:"flex",alignItems:"center",gap:5,flexWrap:"wrap",color:C.text}}>{sig.token}<Badge label={sig.dir} color={sig.dir==="LONG"?"green":"red"}/>{sig.src==="trade.xyz"&&<Badge label="trade.xyz" color="blue"/>}{sig.src==="phantom"&&<Badge label="phantom" color="pink"/>}<span style={{fontSize:8,color:C.muted,fontFamily:MONO}}>{sig.time}</span></div><div style={{fontSize:10,color:C.muted2,lineHeight:1.65,marginTop:3}}>{sig.desc}</div><div style={{display:"flex",gap:3,marginTop:5,flexWrap:"wrap"}}>{sig.tags.map((tg,j)=><Badge key={j} label={tg.l} color={tg.c}/>)}<span style={{fontFamily:MONO,fontSize:8,color:C.muted}}>≤{sig.lev}</span></div></div><div style={{display:"flex",flexDirection:"column",alignItems:"flex-end",gap:5}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:22,color:sig.conf>=85?C.gold2:sig.conf>=70?C.gold:C.orange,lineHeight:1}}>{sig.conf}</div><button onClick={()=>shareSignal(sig)} style={{background:"none",border:`1px solid ${C.border}`,borderRadius:2,color:C.muted2,cursor:"pointer",fontFamily:MONO,fontSize:8,padding:"2px 7px"}}>share</button></div></div></div>);

  const todayDate=new Date();
  const bankColor={FED:C.blue,ECB:C.purple,BOJ:C.teal,BOC:C.gold,BOE:C.green,"US CPI":C.orange,NFP:C.red,PCE:C.orange};
  const upcomingCount=MACRO_EVENTS.filter(e=>{const d=new Date(e.date);return(d-todayDate)/86400000<=7&&(d-todayDate)/86400000>=0;}).length;
  const nextEvents=MACRO_EVENTS.map(e=>{const[y,mo,d]=e.date.split("-").map(Number);const[h,m]=e.timeET.split(":").map(Number);const t=new Date(Date.UTC(y,mo-1,d,h+5,m,0));return{...e,target:t,diffMs:t-todayDate};}).filter(e=>e.diffMs>0).sort((a,b)=>a.diffMs-b.diffMs);
  const filteredMacro=macroFilter==="ALL"?MACRO_EVENTS:MACRO_EVENTS.filter(e=>e.bank===macroFilter||e.bank.startsWith(macroFilter));
  const sortedMacro=[...filteredMacro].sort((a,b)=>new Date(a.date)-new Date(b.date));
  const hlLive=hlStatus==="live",fhLive=fhStatus==="live";
  const filtSigs=signals.filter(s=>{if(sigSubTab==="all")return true;if(sigSubTab==="watch")return watchlist.includes(s.token);if(sigSubTab==="crypto")return s.src==="hyperliquid";if(sigSubTab==="equity")return s.src==="trade.xyz";if(sigSubTab==="metals")return["XAU","XAG"].includes(s.token);if(sigSubTab==="forex")return FOREX_SYMS.includes(s.token);return true;});

  // social filter
  const filteredSocial=socialFeed.filter(item=>{if(socialFilter==="all")return true;if(socialFilter==="twitter")return item.source==="twitter";if(socialFilter==="truth")return item.source==="truth";if(socialFilter==="reddit")return item.source==="reddit";if(socialFilter==="news")return item.source==="cryptopanic";if(socialFilter==="watchlist")return item.assets?.some(a=>watchlist.includes(a));return true;});

  // sentiment color
  const sentColor=overallSentiment.score>=7?C.green:overallSentiment.score>=5?C.orange:C.red;
  const sentBg=overallSentiment.score>=7?"rgba(0,199,135,.08)":overallSentiment.score>=5?"rgba(255,140,0,.08)":"rgba(255,64,96,.08)";

  const NAV=[{k:"radar",icon:"📡",label:"Radar"},{k:"social",icon:"📣",label:"Social"},{k:"poly",icon:"🎯",label:"Poly"},{k:"prices",icon:"💹",label:"Markets"},{k:"signals",icon:"⚡",label:"Signals"},{k:"ai",icon:"✦",label:"AI"}];

  return(
    <div style={{fontFamily:SANS,background:C.bg,color:C.text,minHeight:"100vh",paddingBottom:76,maxWidth:640,margin:"0 auto",position:"relative"}}>
      <style>{`@import url('https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,400;0,700;0,900;1,400;1,700&family=IBM+Plex+Mono:wght@300;400;500;600&family=Barlow:wght@300;400;500;600;700&display=swap'); *{-webkit-tap-highlight-color:transparent;box-sizing:border-box;} select,input,textarea{outline:none;} ::-webkit-scrollbar{display:none;} body::before{content:'';position:fixed;inset:0;background-image:linear-gradient(rgba(20,30,53,.35) 1px,transparent 1px),linear-gradient(90deg,rgba(20,30,53,.35) 1px,transparent 1px);background-size:60px 60px;pointer-events:none;z-index:0;} body::after{content:'';position:fixed;inset:0;background:radial-gradient(ellipse 80% 40% at 50% 0%,rgba(201,168,76,.05) 0%,transparent 60%);pointer-events:none;z-index:0;} @keyframes pulse{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.4;transform:scale(.7)}} @keyframes slideDown{from{transform:translateY(-100%);opacity:0}to{transform:translateY(0);opacity:1}}`}</style>

      {activeAlerts.length>0&&<div style={{animation:"slideDown .3s ease"}}><AlertBanner alerts={activeAlerts} onDismiss={dismissAlert}/></div>}
      {toast&&<Toast msg={toast} onDone={()=>setToast(null)}/>}

      {/* ── HEADER ── */}
      <div style={{padding:"12px 14px 10px",borderBottom:`1px solid ${C.border}`,position:"sticky",top:activeAlerts.length>0?68:0,background:"rgba(5,7,9,.96)",zIndex:50,backdropFilter:"blur(14px)",transition:"top .3s"}}>
        <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:10}}>
          <div><div style={{fontFamily:SERIF,fontWeight:900,fontSize:20,color:C.gold2,letterSpacing:"0.04em",lineHeight:1,textShadow:"0 0 24px rgba(201,168,76,.25)"}}>CLVRQuant</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted,letterSpacing:"0.25em",marginTop:2}}>TRADE SMARTER WITH AI · v4</div></div>
          <div style={{display:"flex",alignItems:"center",gap:8}}>
            {/* SENTIMENT PILL */}
            <div onClick={()=>setTab("social")} style={{background:sentBg,border:`1px solid ${sentColor}44`,borderRadius:2,padding:"3px 8px",cursor:"pointer"}}>
              <div style={{fontFamily:MONO,fontSize:7,color:sentColor,letterSpacing:"0.1em"}}>{overallSentiment.bias}</div>
              <div style={{fontFamily:SERIF,fontWeight:900,fontSize:11,color:sentColor,lineHeight:1}}>{overallSentiment.score}/10</div>
            </div>
            <button onClick={requestPush} style={{background:"none",border:`1px solid ${notifPerm==="granted"?C.gold:C.border}`,borderRadius:2,padding:"4px 8px",cursor:"pointer",fontFamily:MONO,fontSize:10,color:notifPerm==="granted"?C.gold:C.muted2}}>{notifPerm==="granted"?"🔔":"🔕"}</button>
            <div style={{textAlign:"right"}}><div style={{display:"flex",alignItems:"center",gap:5,justifyContent:"flex-end",marginBottom:2}}><LiveDot live={hlLive}/><span style={{fontFamily:MONO,fontSize:7,color:hlLive?C.green:C.orange}}>HL</span><LiveDot live={fhLive}/><span style={{fontFamily:MONO,fontSize:7,color:fhLive?C.green:C.gold}}>FH</span></div><div style={{fontFamily:MONO,fontSize:7,color:C.muted}}>{lastUpdate.toLocaleTimeString()}</div></div>
          </div>
        </div>
        <div style={{display:"flex",gap:5,overflowX:"auto",paddingBottom:2}}>
          {["BTC","ETH","SOL","XAU","XAG","EURUSD","TSLA","NVDA"].map(sym=>{const d=allPrices[sym],flash=flashes[sym];const isUp=Number(d?.chg)>=0;return(<div key={sym} onClick={()=>{setAiInput(`${sym} — long or short right now?`);setTab("ai");}} style={{background:flash==="green"?"rgba(0,199,135,.08)":flash==="red"?"rgba(255,64,96,.06)":C.panel,border:`1px solid ${d?.live?"rgba(201,168,76,.18)":C.border}`,borderRadius:2,padding:"5px 9px",flexShrink:0,cursor:"pointer",minWidth:64,transition:"background .35s"}}><div style={{fontFamily:MONO,fontSize:7,color:d?.live?C.gold:C.muted}}>{sym}</div><div style={{fontFamily:MONO,fontSize:10,fontWeight:600,color:flash==="green"?C.green:flash==="red"?C.red:C.white,transition:"color .35s",marginTop:1}}>{fmt(d?.price,sym)}</div><div style={{fontFamily:MONO,fontSize:8,color:isUp?C.green:C.red}}>{pct(d?.chg)}</div></div>);})}
        </div>
      </div>

      <div style={{padding:"10px 12px",position:"relative",zIndex:1}}>

        {/* ══ RADAR ══ */}
        {tab==="radar"&&<>
          <div style={{marginBottom:14}}><SLabel>Detection Radar · v3</SLabel></div>

          {notifPerm!=="granted"&&<div style={{...panel,border:`1px solid rgba(201,168,76,.25)`,marginBottom:14}}><div style={{padding:"14px 16px",background:"rgba(201,168,76,.05)",display:"flex",alignItems:"center",gap:12}}><span style={{fontSize:22}}>🔔</span><div style={{flex:1}}><div style={{fontFamily:SERIF,fontWeight:700,fontSize:13,color:C.white,marginBottom:4}}>Enable Push Notifications</div><div style={{fontSize:10,color:C.muted2,lineHeight:1.6}}>Alerts: macro countdowns · volume spikes · funding flips · social intelligence.</div></div><button onClick={requestPush} style={{background:C.gold,color:C.bg,border:"none",borderRadius:2,padding:"8px 14px",fontFamily:SERIF,fontStyle:"italic",fontWeight:700,fontSize:12,cursor:"pointer",flexShrink:0}}>Enable →</button></div></div>}

          {/* SENTIMENT OVERVIEW */}
          <div style={{...panel,border:`1px solid ${sentColor}33`,background:sentBg}}>
            <div style={{...ph,background:"transparent",borderBottomColor:`${sentColor}22`}}>
              <PTitle>📡 Market Sentiment</PTitle>
              <Badge label={overallSentiment.bias} color={overallSentiment.score>=7?"green":overallSentiment.score>=5?"orange":"red"}/>
            </div>
            <div style={{padding:"12px 14px",display:"grid",gridTemplateColumns:"1fr 1fr 1fr",gap:10}}>
              <div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:28,color:sentColor,lineHeight:1}}>{overallSentiment.score}</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted,letterSpacing:"0.12em",marginTop:3}}>SCORE /10</div></div>
              <div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:700,fontSize:14,color:sentColor,lineHeight:1.2}}>{overallSentiment.label}</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted,letterSpacing:"0.12em",marginTop:3}}>LABEL</div></div>
              <div style={{textAlign:"center"}}><div style={{fontFamily:MONO,fontSize:9,color:sentColor,fontWeight:700}}>{socialFeed.length}</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted,letterSpacing:"0.12em",marginTop:3}}>SIGNALS</div></div>
            </div>
            <div style={{padding:"0 14px 12px"}}>
              <div style={{display:"flex",gap:6,flexWrap:"wrap"}}>
                {["twitter","truth","reddit","cryptopanic"].map(src=>{const count=socialFeed.filter(s=>s.source===src).length;const srcColor={twitter:C.cyan,truth:C.red,reddit:C.orange,cryptopanic:C.blue}[src];const label={twitter:"X/Twitter",truth:"Truth Social",reddit:"Reddit",cryptopanic:"News"}[src];return<div key={src} style={{background:"rgba(0,0,0,.2)",border:`1px solid ${srcColor}22`,borderRadius:2,padding:"4px 8px"}}><div style={{fontFamily:MONO,fontSize:7,color:srcColor}}>{label}</div><div style={{fontFamily:MONO,fontSize:9,fontWeight:600,color:C.text}}>{count} posts</div></div>;})}
              </div>
            </div>
          </div>

          {activeAlerts.length>0&&<div style={panel}><div style={ph}><PTitle>⚡ Live Alerts</PTitle><Badge label={`${activeAlerts.length}`} color="red"/></div>{activeAlerts.map(a=>{const col={macro:C.orange,volume:C.cyan,funding:C.green,liq:C.red,social:C.purple,price:C.gold}[a.type]||C.gold;return(<div key={a.id} style={{padding:"11px 14px",borderBottom:`1px solid ${C.border}`,display:"flex",gap:10,alignItems:"flex-start"}}><div style={{flex:1}}><div style={{fontFamily:MONO,fontSize:9,fontWeight:600,color:col,letterSpacing:"0.12em",marginBottom:3}}>{a.title}</div><div style={{fontSize:10,color:C.text,lineHeight:1.65}}>{a.body}</div>{a.assets&&a.assets.length>0&&<div style={{display:"flex",gap:4,marginTop:5,flexWrap:"wrap"}}>{a.assets.map(sym=><span key={sym} style={{fontFamily:MONO,fontSize:8,color:col,background:"rgba(0,0,0,.2)",border:`1px solid ${C.border}`,borderRadius:2,padding:"1px 6px"}}>{sym}</span>)}</div>}</div><button onClick={()=>dismissAlert(a.id)} style={{background:"none",border:"none",color:C.muted,cursor:"pointer",fontSize:16,padding:0}}>×</button></div>);})}</div>}

          {nextEvents.length>0&&(()=>{const e=nextEvents[0];const bc=bankColor[e.bank]||C.gold;const isHot=e.diffMs<30*60*1000;return(<div style={{...panel,border:`1px solid ${isHot?"rgba(255,64,96,.35)":"rgba(201,168,76,.2)"}`}}><div style={{...ph,background:"transparent"}}><div style={{display:"flex",alignItems:"center",gap:8}}>{isHot&&<div style={{width:8,height:8,borderRadius:"50%",background:C.red,boxShadow:`0 0 8px ${C.red}`,animation:"pulse 1s infinite"}}/>}<PTitle>{isHot?"🚨 IMMINENT":"⏱ Next Event"}</PTitle></div><Badge label={e.impact} color="red"/></div><div style={{padding:"14px 14px"}}><div style={{display:"flex",alignItems:"center",gap:8,marginBottom:10}}><span style={{fontSize:16}}>{e.flag}</span><div><div style={{fontFamily:MONO,fontWeight:600,fontSize:9,color:bc}}>{e.bank}</div><div style={{fontFamily:SERIF,fontWeight:700,fontSize:13,color:C.white}}>{e.name}</div><div style={{fontFamily:MONO,fontSize:8,color:C.muted,marginTop:1}}>{e.date} · {e.timeET} ET · {e.forecast}</div></div></div><Countdown dateStr={e.date} timeET={e.timeET}/><div style={{marginTop:10,fontSize:10,color:C.muted2,lineHeight:1.7,padding:"7px 10px",background:"rgba(0,0,0,.2)",borderRadius:2,borderLeft:`2px solid ${bc}44`}}>{e.desc}</div><div style={{display:"flex",gap:5,flexWrap:"wrap",marginTop:10}}>{e.assets?.map(sym=>{const d=allPrices[sym];return<div key={sym} style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:2,padding:"4px 9px"}}><div style={{fontFamily:MONO,fontSize:7,color:bc}}>{sym}</div><div style={{fontFamily:MONO,fontSize:10,color:C.white}}>{fmt(d?.price,sym)}</div></div>;})}</div>{(()=>{const linked=POLY_MARKETS.filter(pm=>pm.macroId===e.id);if(!linked.length)return null;return(<div style={{marginTop:10,padding:"10px 12px",background:"rgba(0,0,0,.25)",borderRadius:2,border:`1px solid rgba(201,168,76,.12)`}}><div style={{fontFamily:MONO,fontSize:7,color:C.gold,letterSpacing:"0.2em",marginBottom:8}}>🎯 POLYMARKET ODDS</div>{linked.map(pm=>{const o=polyOdds[pm.id];if(!o)return null;const shift=o.yes-(o.prev??o.yes);return(<div key={pm.id} style={{marginBottom:6}}><div style={{fontFamily:MONO,fontSize:9,color:C.muted2,marginBottom:3}}>{pm.label}</div><OddsBar yes={o.yes} prev={o.prev} size="normal"/></div>);})}</div>);})()}<button onClick={()=>{setAiInput(`${e.bank} ${e.name} on ${e.date}. Forecast: ${e.forecast}. How to position? Entry, stop, TP.`);setTab("ai");}} style={{width:"100%",height:36,marginTop:12,background:"rgba(201,168,76,.1)",color:C.gold2,border:`1px solid rgba(201,168,76,.3)`,borderRadius:2,fontFamily:SERIF,fontStyle:"italic",fontWeight:700,fontSize:13,cursor:"pointer"}}>Ask AI How to Position →</button></div></div>);})()} 

          {/* VOLUME + FUNDING */}
          <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
            <div style={panel}><div style={{...ph,padding:"9px 12px"}}><PTitle style={{fontSize:11}}>Vol Spikes</PTitle><Badge label="5x" color="cyan"/></div>{CRYPTO_SYMS.slice(0,5).map(sym=>{const d=cryptoPrices[sym];const hist=d?.volHistory||[];const avg=hist.length>=2?hist.slice(-5).reduce((a,b)=>a+b,0)/Math.min(5,hist.length):0;const ratio=avg>0&&d?.volume>0?d.volume/avg:1;const spiking=ratio>=3;return(<div key={sym} style={{padding:"7px 12px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:6}}><span style={{fontFamily:MONO,fontSize:9,color:spiking?C.cyan:C.muted2,width:36,flexShrink:0}}>{sym}</span><div style={{flex:1,position:"relative",height:5,background:"rgba(0,0,0,.3)",borderRadius:1}}><div style={{position:"absolute",left:0,top:0,bottom:0,width:`${Math.min(ratio/8*100,100)}%`,background:spiking?"rgba(0,212,255,.7)":"rgba(201,168,76,.3)",borderRadius:1,transition:"width .5s"}}/></div><span style={{fontFamily:MONO,fontSize:8,color:spiking?C.cyan:C.muted,width:26,textAlign:"right"}}>{ratio.toFixed(1)}×</span></div>);})}</div>
            <div style={panel}><div style={{...ph,padding:"9px 12px"}}><PTitle style={{fontSize:11}}>Funding</PTitle><Badge label="FLIP" color="green"/></div>{CRYPTO_SYMS.slice(0,5).map(sym=>{const d=cryptoPrices[sym];const f=d?.funding||0;const hist=d?.fundHistory||[];const prev=hist.length>=2?hist[hist.length-2]:0;const flipped=prev<0&&f>0.005?"↑":prev>0&&f<-0.005?"↓":"";return(<div key={sym} style={{padding:"7px 12px",borderBottom:`1px solid ${C.border}`,display:"flex",alignItems:"center",gap:6}}><span style={{fontFamily:MONO,fontSize:9,color:C.text,width:36,flexShrink:0}}>{sym}</span><span style={{fontFamily:MONO,fontSize:9,color:f>0.03?C.red:f<-0.03?C.green:C.muted2,flex:1,textAlign:"right"}}>{pct(f,4)}</span>{flipped&&<span style={{fontFamily:MONO,fontSize:10,color:flipped==="↑"?C.green:C.red,fontWeight:700}}>{flipped}</span>}</div>);})}</div>
          </div>

          {/* LIQ HEATMAP */}
          <div style={panel}><div style={ph}><PTitle>Liquidation Heatmap</PTitle><div style={{display:"flex",gap:4}}>{["BTC","ETH","SOL","XAU"].map(s=><button key={s} onClick={()=>setLiqSym(s)} style={{padding:"2px 8px",borderRadius:2,border:`1px solid ${liqSym===s?C.gold:C.border}`,background:"none",color:liqSym===s?C.gold:C.muted2,fontFamily:MONO,fontSize:8,cursor:"pointer"}}>{s}</button>)}</div></div><div style={{padding:"14px"}}><LiqHeatmap sym={liqSym} price={allPrices[liqSym]?.price}/></div></div>
        </>}

        {/* ══ SOCIAL ══ */}
        {tab==="social"&&<>
          <div style={{marginBottom:14}}><SLabel>Social Intelligence</SLabel></div>

          {/* SENTIMENT CARD */}
          <div style={{...panel,border:`1px solid ${sentColor}33`}}>
            <div style={{...ph,background:sentBg}}><PTitle>Live Sentiment Score</PTitle><div style={{display:"flex",alignItems:"center",gap:6}}><Badge label={overallSentiment.bias} color={overallSentiment.score>=7?"green":overallSentiment.score>=5?"orange":"red"}/><button onClick={fetchSocial} style={{background:"none",border:`1px solid ${C.border}`,borderRadius:2,padding:"2px 7px",color:C.muted2,fontFamily:MONO,fontSize:7,cursor:"pointer"}}>{socialLoading?"…":"↻"}</button></div></div>
            <div style={{padding:"14px",display:"grid",gridTemplateColumns:"auto 1fr",gap:16,alignItems:"center"}}>
              <div style={{textAlign:"center"}}><div style={{fontFamily:SERIF,fontWeight:900,fontSize:48,color:sentColor,lineHeight:1,textShadow:`0 0 20px ${sentColor}44`}}>{overallSentiment.score}</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted,letterSpacing:"0.15em"}}>OUT OF 10</div></div>
              <div>
                <div style={{fontFamily:SERIF,fontWeight:700,fontSize:16,color:sentColor,marginBottom:6}}>{overallSentiment.label}</div>
                <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:6}}>
                  {["twitter","truth","reddit","cryptopanic"].map(src=>{const items=socialFeed.filter(s=>s.source===src);const avg=items.length?+(items.reduce((a,b)=>a+b.score,0)/items.length).toFixed(1):0;const col={twitter:C.cyan,truth:C.red,reddit:C.orange,cryptopanic:C.blue}[src];const label={twitter:"𝕏 Twitter",truth:"Truth Social",reddit:"Reddit",cryptopanic:"Crypto News"}[src];return(<div key={src} style={{background:"rgba(0,0,0,.2)",borderRadius:2,padding:"5px 7px"}}><div style={{fontFamily:MONO,fontSize:7,color:col,marginBottom:2}}>{label}</div><SentimentBar score={avg} color={col}/></div>);})}
                </div>
              </div>
            </div>
            {socialLastFetch&&<div style={{padding:"0 14px 10px",fontFamily:MONO,fontSize:7,color:C.muted}}>Updated {timeAgo(socialLastFetch)} · Refreshes every 2min</div>}
          </div>

          {/* FILTER */}
          <div style={{display:"flex",gap:4,marginBottom:10,overflowX:"auto"}}>
            {[{k:"all",l:"All"},{k:"twitter",l:"𝕏 Twitter",col:"cyan"},{k:"truth",l:"Truth Social",col:"red"},{k:"reddit",l:"Reddit",col:"orange"},{k:"news",l:"News",col:"blue"},{k:"watchlist",l:"✦ Watch",col:"gold"}].map(t=>(<SubBtn key={t.k} k={t.k} label={t.l} col={t.col||"gold"} state={socialFilter} setter={setSocialFilter}/>))}
          </div>

          {/* API STATUS */}
          <div style={{...panel,marginBottom:10}}>
            <div style={{padding:"10px 14px",display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
              {[{label:"CryptoPanic",key:CRYPTOPANIC_KEY,keyName:"CRYPTOPANIC_KEY",color:C.blue,url:"cryptopanic.com",cost:"Free"},{label:"Twitter/X",key:RAPIDAPI_KEY,keyName:"RAPIDAPI_KEY",color:C.cyan,url:"rapidapi.com",cost:"~$10/mo"},{label:"Truth Social",key:"rss",keyName:"RSS (auto)",color:C.red,url:"Public RSS",cost:"Free"},{label:"Reddit",key:"open",keyName:"Open API",color:C.orange,url:"reddit.com/dev",cost:"Free"}].map(s=>{const configured=s.key!=="YOUR_CRYPTOPANIC_KEY_HERE"&&s.key!=="YOUR_RAPIDAPI_KEY_HERE"&&s.key;return(<div key={s.label} style={{background:configured?"rgba(0,199,135,.05)":"rgba(0,0,0,.2)",border:`1px solid ${configured?s.color+"33":C.border}`,borderRadius:2,padding:"8px 10px"}}><div style={{display:"flex",alignItems:"center",gap:5,marginBottom:3}}><div style={{width:5,height:5,borderRadius:"50%",background:configured?C.green:C.orange}}/><span style={{fontFamily:MONO,fontSize:8,color:s.color,fontWeight:600}}>{s.label}</span></div><div style={{fontFamily:MONO,fontSize:7,color:C.muted}}>{configured?"LIVE":"Add key in App.js"}</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted2}}>{s.cost}</div></div>);})}
            </div>
          </div>

          {/* SOCIAL FEED */}
          <div style={panel}>
            <div style={ph}><PTitle>Live Feed</PTitle><Badge label={`${filteredSocial.length} posts`} color="purple"/></div>
            {filteredSocial.map(item=>{
              const isWatchedAsset=item.assets?.some(a=>watchlist.includes(a));
              const sentCol=item.score>=7?C.green:item.score>=5?C.orange:C.red;
              return(<div key={item.id} style={{padding:"12px 14px",borderBottom:`1px solid ${C.border}`,background:isWatchedAsset?"rgba(201,168,76,.02)":"transparent"}}>
                <div style={{display:"flex",alignItems:"flex-start",gap:10}}>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap",marginBottom:5}}>
                      <SourceIcon source={item.source} color={item.color} icon={item.icon}/>
                      <span style={{fontFamily:MONO,fontSize:8,color:C.muted2,fontWeight:600}}>@{item.handle}</span>
                      <span style={{fontFamily:MONO,fontSize:7,color:C.muted}}>{timeAgo(item.ts)}</span>
                      {isWatchedAsset&&<Badge label="WATCHLIST" color="gold"/>}
                    </div>
                    <div style={{fontSize:11,color:C.text,lineHeight:1.7,marginBottom:7}}>{item.text}</div>
                    {item.assets&&item.assets.length>0&&<div style={{display:"flex",gap:4,flexWrap:"wrap",marginBottom:6}}>
                      {item.assets.map(sym=>{const d=allPrices[sym];return(<div key={sym} onClick={()=>{setAiInput(`${sym} — given this social post: "${item.text.slice(0,100)}", long or short?`);setTab("ai");}} style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:2,padding:"3px 7px",cursor:"pointer"}}>
                        <span style={{fontFamily:MONO,fontSize:7,color:C.gold}}>{sym}</span>
                        {d&&<span style={{fontFamily:MONO,fontSize:7,color:C.muted2,marginLeft:4}}>{fmt(d.price,sym)}</span>}
                      </div>);})}
                    </div>}
                    <div style={{display:"flex",alignItems:"center",gap:8}}>
                      <SentimentBar score={item.score}/>
                      <button onClick={()=>{setAiInput(`Analyze this social signal for trading implications: "${item.text}"\n\nAssets mentioned: ${item.assets?.join(", ")||"general market"}. Should I trade this? Which direction?`);setTab("ai");}} style={{background:"none",border:`1px solid ${C.border}`,color:C.muted2,borderRadius:2,padding:"2px 8px",fontFamily:MONO,fontSize:7,cursor:"pointer"}}>Ask AI ✦</button>
                      {item.url&&item.url!=="#"&&<a href={item.url} target="_blank" rel="noopener noreferrer" style={{fontFamily:MONO,fontSize:7,color:C.muted2,textDecoration:"none"}}>↗ source</a>}
                    </div>
                  </div>
                </div>
              </div>);
            })}
          </div>
        </>}

        {/* ══ MARKETS ══ */}
        {tab==="prices"&&<>
          <div style={{marginBottom:14}}><SLabel>Market Data</SLabel></div>
          <div style={{display:"flex",gap:4,marginBottom:10,overflowX:"auto"}}>{[{k:"crypto",l:"Crypto"},{k:"equity",l:"Equities",col:"blue"},{k:"metals",l:"Metals"},{k:"forex",l:"Forex",col:"teal"}].map(t=>(<SubBtn key={t.k} k={t.k} label={t.l} col={t.col||"gold"} state={priceTab} setter={setPriceTab}/>))}</div>
          {priceTab==="crypto"&&<div style={panel}><div style={ph}><PTitle>Crypto · Hyperliquid</PTitle><Badge label={hlLive?"LIVE":"Connecting"} color={hlLive?"green":"orange"}/></div>{CRYPTO_SYMS.map(sym=>{const d=cryptoPrices[sym];return(<div key={sym}><PriceRow sym={sym} d={d} extra={d?.live&&d.funding?`Fund: ${pct(d.funding,4)}/8h · OI: $${(d.oi/1e6).toFixed(0)}M`:null}/>{d?.oiHistory?.length>3&&<div style={{padding:"2px 14px 8px",display:"flex",alignItems:"center",gap:8}}><span style={{fontFamily:MONO,fontSize:7,color:C.muted,flexShrink:0}}>OI</span><Sparkline data={d.oiHistory} width={90} height={18}/></div>}</div>);})}</div>}
          {priceTab==="equity"&&<div style={panel}><div style={ph}><PTitle>Equities</PTitle><Badge label={fhLive?"Live":"Closed"} color={fhLive?"green":"gold"}/></div>{EQUITY_SYMS.map(sym=><PriceRow key={sym} sym={sym} d={equityPrices[sym]}/>)}</div>}
          {priceTab==="metals"&&<div style={panel}><div style={ph}><PTitle>Metals</PTitle></div>{METALS_SYMS.map(sym=><PriceRow key={sym} sym={sym} d={metalPrices[sym]}/>)}<div style={{padding:"10px 14px",fontFamily:MONO,fontSize:9,color:C.muted2}}>Gold/Silver: <span style={{color:C.gold2}}>{metalPrices.XAU?.price&&metalPrices.XAG?.price?(metalPrices.XAU.price/metalPrices.XAG.price).toFixed(0):"—"}:1</span></div></div>}
          {priceTab==="forex"&&<div style={panel}><div style={ph}><PTitle>Forex</PTitle><Badge label={fhLive?"Live":"Closed"} color={fhLive?"green":"gold"}/></div>{FOREX_SYMS.map(sym=><PriceRow key={sym} sym={sym} d={forexPrices[sym]}/>)}</div>}
        </>}


        {/* ══ POLYMARKET ══ */}
        {tab==="poly"&&<>
          <div style={{marginBottom:14}}><SLabel>Polymarket · Prediction Markets</SLabel></div>

          {/* SUMMARY CARD */}
          <div style={{...panel,border:`1px solid rgba(201,168,76,.2)`,marginBottom:10}}>
            <div style={{...ph}}>
              <PTitle>🎯 Real-Money Odds</PTitle>
              <div style={{display:"flex",alignItems:"center",gap:8}}>
                <div style={{display:"flex",alignItems:"center",gap:4}}>
                  <div style={{width:5,height:5,borderRadius:"50%",background:Object.values(polyOdds).some(o=>o.live)?C.green:C.orange}}/>
                  <span style={{fontFamily:MONO,fontSize:7,color:Object.values(polyOdds).some(o=>o.live)?C.green:C.orange}}>
                    {Object.values(polyOdds).some(o=>o.live)?"LIVE":"CACHED"}
                  </span>
                </div>
                <button onClick={doPolyFetch} style={{background:"none",border:`1px solid ${C.border}`,borderRadius:2,padding:"2px 7px",color:C.muted2,fontFamily:MONO,fontSize:7,cursor:"pointer"}}>{polyLoading?"…":"↻"}</button>
              </div>
            </div>
            <div style={{padding:"10px 14px",display:"grid",gridTemplateColumns:"repeat(3,1fr)",gap:8}}>
              {[
                {label:"Macro", cat:"macro",   col:C.orange, icon:"🏦"},
                {label:"Crypto",cat:"crypto",  col:C.gold,   icon:"₿"},
                {label:"Trump", cat:"trump",   col:C.red,    icon:"🇺🇸"},
              ].map(({label,cat,col,icon})=>{
                const markets=POLY_MARKETS.filter(m=>m.cat===cat);
                const avgYes=markets.length?Math.round(markets.reduce((a,m)=>a+(polyOdds[m.id]?.yes??50),0)/markets.length):50;
                return(<div key={cat} onClick={()=>setPolyCat(cat)} style={{background:polyCat===cat?`${col}12`:"rgba(0,0,0,.2)",border:`1px solid ${polyCat===cat?col+"40":C.border}`,borderRadius:2,padding:"8px 10px",cursor:"pointer",textAlign:"center"}}>
                  <div style={{fontSize:16,marginBottom:4}}>{icon}</div>
                  <div style={{fontFamily:MONO,fontSize:8,color:col,marginBottom:3}}>{label}</div>
                  <div style={{fontFamily:SERIF,fontWeight:900,fontSize:20,color:oddsColor(avgYes)}}>{avgYes}%</div>
                  <div style={{fontFamily:MONO,fontSize:7,color:C.muted}}>avg YES</div>
                </div>);
              })}
            </div>
            {polyLastFetch&&<div style={{padding:"0 14px 10px",fontFamily:MONO,fontSize:7,color:C.muted}}>Updated {timeAgo(polyLastFetch)} · Refreshes every 60s · Data: Polymarket</div>}
          </div>

          {/* CATEGORY FILTER */}
          <div style={{display:"flex",gap:4,marginBottom:10,overflowX:"auto"}}>
            {[{k:"all",l:"All Markets"},{k:"macro",l:"🏦 Macro",col:"orange"},{k:"crypto",l:"₿ Crypto",col:"gold"},{k:"trump",l:"🇺🇸 Trump",col:"red"}].map(t=>(
              <SubBtn key={t.k} k={t.k} label={t.l} col={t.col||"gold"} state={polyCat} setter={setPolyCat}/>
            ))}
          </div>

          {/* MARKETS LIST */}
          <div style={panel}>
            <div style={ph}><PTitle>Market Odds</PTitle><Badge label={`${POLY_MARKETS.filter(m=>polyCat==="all"||m.cat===polyCat).length} markets`} color="gold"/></div>
            {POLY_MARKETS.filter(m=>polyCat==="all"||m.cat===polyCat).map(m=>{
              const o=polyOdds[m.id];
              if(!o)return null;
              const shift=o.yes-(o.prev??o.yes);
              const isHot=Math.abs(shift)>=8;
              const catCol={macro:C.orange,crypto:C.gold,trump:C.red}[m.cat]||C.gold;
              return(<div key={m.id} style={{padding:"13px 14px",borderBottom:`1px solid ${C.border}`,background:isHot?"rgba(201,168,76,.03)":"transparent"}}>
                <div style={{display:"flex",alignItems:"flex-start",gap:10}}>
                  <div style={{flex:1}}>
                    <div style={{display:"flex",alignItems:"center",gap:6,flexWrap:"wrap",marginBottom:6}}>
                      <Badge label={{macro:"MACRO",crypto:"CRYPTO",trump:"POLITICAL"}[m.cat]||m.cat} color={{macro:"orange",crypto:"gold",trump:"red"}[m.cat]}/>
                      {isHot&&<Badge label={`${shift>0?"+":""}${shift}% SHIFT`} color={shift>0?"green":"red"}/>}
                      {o.live&&<Badge label="LIVE" color="green"/>}
                    </div>
                    <div style={{fontFamily:SANS,fontSize:12,color:C.white,fontWeight:500,marginBottom:8,lineHeight:1.5}}>{m.label}</div>
                    <OddsBar yes={o.yes} prev={o.prev} size="large"/>
                    <div style={{display:"flex",gap:4,flexWrap:"wrap",marginTop:8}}>
                      {m.assets?.map(sym=>{const d=allPrices[sym];return(<div key={sym} onClick={()=>{setAiInput(`Given Polymarket odds on "${m.label}" are ${o.yes}% YES${shift!==0?` (shifted ${shift>0?"+":""}${shift}% recently)`:""}, how should I trade ${sym}? Entry, stop, target.`);setTab("ai");}} style={{background:C.panel,border:`1px solid ${C.border}`,borderRadius:2,padding:"3px 8px",cursor:"pointer"}}>
                        <span style={{fontFamily:MONO,fontSize:7,color:catCol}}>{sym}</span>
                        {d&&<span style={{fontFamily:MONO,fontSize:7,color:C.muted2,marginLeft:4}}>{fmt(d.price,sym)}</span>}
                      </div>);})}
                      <button onClick={()=>{setAiInput(`Polymarket odds on "${m.label}": ${o.yes}% YES${shift!==0?` (${shift>0?"+":""}${shift}% shift recently)`:""}. What does this mean for ${m.assets?.join("/")}? Long or short and why?`);setTab("ai");}} style={{background:"none",border:`1px solid ${C.border}`,color:C.muted2,borderRadius:2,padding:"3px 8px",fontFamily:MONO,fontSize:7,cursor:"pointer"}}>Ask AI ✦</button>
                    </div>
                  </div>
                  <div style={{textAlign:"center",flexShrink:0,minWidth:52}}>
                    <div style={{fontFamily:SERIF,fontWeight:900,fontSize:32,color:oddsColor(o.yes),lineHeight:1}}>{o.yes}</div>
                    <div style={{fontFamily:MONO,fontSize:7,color:C.muted,marginTop:2}}>% YES</div>
                  </div>
                </div>
              </div>);
            })}
          </div>

          {/* HOW TO USE GUIDE */}
          <div style={{...panel,border:`1px solid rgba(0,212,255,.12)`,marginTop:4}}>
            <div style={{padding:"12px 14px"}}>
              <div style={{fontFamily:MONO,fontSize:7,color:C.cyan,letterSpacing:"0.2em",marginBottom:8}}>📖 HOW TO TRADE WITH POLYMARKET</div>
              <div style={{fontSize:10,color:C.muted2,lineHeight:1.9}}>
                <span style={{color:C.text}}>Odds ≥70%</span> — market is pricing this as near-certain. Position with the consensus, tight stops.<br/>
                <span style={{color:C.text}}>Odds 30–70%</span> — genuine uncertainty. Size down, trade the move not the outcome.<br/>
                <span style={{color:C.text}}>Rapid shift ≥10%</span> — smart money repositioning. Strong directional signal — check social + AI.<br/>
                <span style={{color:C.text}}>Odds &lt;30%</span> — market doubts it. Fade the hype. Good contrarian setup if sentiment disagrees.
              </div>
            </div>
          </div>

          <div style={{textAlign:"center",fontFamily:MONO,fontSize:7,color:C.muted,marginTop:6}}>
            DATA: POLYMARKET.COM · REAL-MONEY PREDICTION MARKETS
          </div>
        </>}

        {/* ══ SIGNALS ══ */}
        {tab==="signals"&&<><div style={{marginBottom:14}}><SLabel>Quant AI Signals</SLabel></div><div style={{display:"flex",gap:4,marginBottom:10,overflowX:"auto"}}>{[{k:"all",l:"All"},{k:"watch",l:"✦ Watch"},{k:"crypto",l:"Crypto",col:"green"},{k:"equity",l:"Equities",col:"blue"},{k:"metals",l:"Metals"},{k:"forex",l:"Forex",col:"teal"}].map(t=>(<SubBtn key={t.k} k={t.k} label={t.l} col={t.col||"gold"} state={sigSubTab} setter={setSigSubTab}/>))}</div><div style={panel}><div style={ph}><PTitle>Alpha Signals</PTitle><Badge label={`${sigCount}`} color="gold"/></div>{filtSigs.map(sig=><SignalRow key={sig.id} sig={sig}/>)}</div></>}

        {/* ══ AI ══ */}
        {tab==="ai"&&<>
          <div style={{marginBottom:14}}><SLabel>AI Market Analyst</SLabel></div>

          {/* SOCIAL CONTEXT STATUS */}
          <div style={{...panel,border:`1px solid ${sentColor}22`,marginBottom:10}}>
            <div style={{padding:"9px 14px",display:"flex",alignItems:"center",gap:10}}>
              <div style={{width:6,height:6,borderRadius:"50%",background:C.purple,boxShadow:`0 0 6px ${C.purple}`,flexShrink:0}}/>
              <div style={{flex:1}}><div style={{fontFamily:MONO,fontSize:8,color:C.purple,letterSpacing:"0.12em"}}>SOCIAL INTELLIGENCE ACTIVE</div><div style={{fontFamily:MONO,fontSize:7,color:C.muted,marginTop:1}}>AI has context: {socialFeed.slice(0,6).length} social posts · {POLY_MARKETS.length} Polymarket odds · Sentiment {overallSentiment.score}/10</div></div>
              <Badge label={overallSentiment.bias} color={overallSentiment.score>=7?"green":overallSentiment.score>=5?"orange":"red"}/>
            </div>
          </div>

          <div style={panel}><div style={ph}><PTitle>CLVRQuant AI</PTitle><Badge label="Claude + Social" color="gold"/></div><div style={{padding:16}}>
            {ANTHROPIC_KEY==="YOUR_ANTHROPIC_KEY_HERE"&&<div style={{background:"rgba(255,140,0,.07)",border:`1px solid rgba(255,140,0,.2)`,borderRadius:2,padding:"9px 12px",marginBottom:12,fontFamily:MONO,fontSize:8,color:C.orange}}>⚠ Add Anthropic API key in App.js</div>}
            <div style={{display:"flex",gap:4,marginBottom:10,flexWrap:"wrap"}}>
              {["BTC","ETH","SOL","XAU","EURUSD","TSLA","NVDA"].map(sym=>{const d=allPrices[sym];return<button key={sym} onClick={()=>setAiInput(`${sym} — long or short? Price:${fmt(d?.price,sym)} 24h:${pct(d?.chg)}`)} style={{padding:"4px 10px",borderRadius:2,border:`1px solid ${d?.live?"rgba(201,168,76,.28)":C.border}`,background:C.panel,color:d?.live?C.gold2:C.muted2,fontFamily:MONO,fontSize:8,cursor:"pointer"}}>{sym}{d?.live?" ✦":""}</button>;})}
            </div>
            {/* Social quick prompts */}
            {socialFeed.slice(0,3).some(s=>s.assets?.length>0)&&<div style={{marginBottom:10}}>
              <div style={{fontFamily:MONO,fontSize:7,color:C.purple,letterSpacing:"0.15em",marginBottom:5}}>FROM SOCIAL FEED:</div>
              <div style={{display:"flex",gap:4,flexWrap:"wrap"}}>
                {socialFeed.slice(0,4).filter(s=>s.assets?.length>0).map(s=><button key={s.id} onClick={()=>setAiInput(`Trade idea based on: "${s.text.slice(0,80)}..." — Assets: ${s.assets?.join(", ")}. Score ${s.score}/10. Long or short?`)} style={{padding:"4px 9px",borderRadius:2,border:`1px solid rgba(168,85,247,.25)`,background:"rgba(168,85,247,.07)",color:C.purple,fontFamily:MONO,fontSize:7,cursor:"pointer",maxWidth:200,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{s.icon} {s.assets?.join("/")} signal</button>)}
              </div>
            </div>}
            <textarea value={aiInput} onChange={e=>setAiInput(e.target.value)} placeholder={`"Long BTC?" · "How to trade PCE?" · "What does the Trump post mean for XAU?"`} style={{width:"100%",background:C.inputBg,border:`1px solid ${C.border}`,borderRadius:2,padding:12,color:C.text,fontFamily:SANS,fontSize:11,resize:"none",height:80,lineHeight:1.7}}/>
            <button onClick={runAI} disabled={aiLoading} style={{width:"100%",height:44,marginTop:8,background:"rgba(201,168,76,.1)",color:aiLoading?C.muted:C.gold2,border:`1px solid rgba(201,168,76,.3)`,borderRadius:2,fontFamily:SERIF,fontStyle:"italic",fontWeight:700,fontSize:15,cursor:aiLoading?"not-allowed":"pointer"}}>{aiLoading?"Analyzing…":"Analyze →"}</button>
            {aiOutput&&<div style={{marginTop:12,background:C.inputBg,border:`1px solid ${C.border}`,borderRadius:2,padding:14,fontSize:11,lineHeight:1.9,color:C.text,whiteSpace:"pre-wrap",maxHeight:360,overflowY:"auto"}}>{aiOutput}</div>}
          </div></div>

          <div style={{...panel,border:`1px solid rgba(255,140,0,.12)`}}><div style={{padding:"11px 14px"}}><div style={{fontFamily:MONO,fontSize:7,color:C.orange,letterSpacing:"0.22em",marginBottom:5}}>⚠ LEGAL DISCLAIMER</div><div style={{fontSize:9,color:C.muted,lineHeight:1.9}}>CLVRQuant is for <strong style={{color:C.muted2}}>informational purposes only</strong>. Not financial advice. Social signals are crowd-sourced, not verified. © 2025 CLVRQuant · Mike Claver™.</div></div></div>
        </>}

        <div style={{textAlign:"center",fontFamily:MONO,fontSize:7,color:C.muted,marginTop:6,letterSpacing:"0.12em"}}>HYPERLIQUID · FINNHUB · CRYPTOPANIC · POLYMARKET · © 2025 CLVRQUANT</div>
      </div>

      {/* BOTTOM NAV */}
      <div style={{position:"fixed",bottom:0,left:0,right:0,zIndex:100,background:"rgba(5,7,9,.97)",borderTop:`1px solid ${C.border}`,backdropFilter:"blur(14px)",display:"flex",paddingBottom:"env(safe-area-inset-bottom,0px)"}}>
        {NAV.map(item=>{const active=tab===item.k;const hasAlert=(item.k==="radar"&&activeAlerts.length>0)||(item.k==="social"&&socialFeed.some(s=>s.score>=8&&s.assets?.some(a=>watchlist.includes(a))))||(item.k==="poly"&&POLY_MARKETS.some(m=>{const o=polyOdds[m.id];return o&&Math.abs(o.yes-(o.prev??o.yes))>=10;}));return(<button key={item.k} onClick={()=>setTab(item.k)} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"8px 2px 10px",background:"none",border:"none",borderTop:`2px solid ${active?C.gold:"transparent"}`,position:"relative",cursor:"pointer",transition:"border-color .2s"}}><span style={{fontSize:item.k==="ai"?16:18,lineHeight:1,fontFamily:item.k==="ai"?SERIF:"inherit",fontWeight:item.k==="ai"?900:"inherit",color:active?C.gold:C.muted2}}>{item.icon}</span>{hasAlert&&!active&&<div style={{position:"absolute",top:5,right:"calc(50% - 14px)",width:7,height:7,borderRadius:"50%",background:C.red,animation:"pulse 1.2s infinite"}}/>}<span style={{fontFamily:MONO,fontSize:7,marginTop:4,color:active?C.gold:C.muted,letterSpacing:"0.15em",fontWeight:active?600:400,textTransform:"uppercase"}}>{item.label}</span></button>);})}
      </div>
    </div>
  );
}
