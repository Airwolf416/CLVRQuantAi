# 🚀 ALPHASCAN v10 — Deployment Guide

Real-time perp intelligence dashboard covering:
- **Crypto** (Hyperliquid) — BTC, ETH, SOL, WIF, DOGE, AVAX, LINK, ARB, PEPE
- **Stocks** (trade.xyz) — TSLA, NVDA, AAPL, GOOGL, META, MSFT, AMZN, MSTR  
- **Metals** (Phantom) — XAU (Gold), XAG (Silver)
- **Forex** (Phantom) — EURUSD, GBPUSD, USDJPY, USDCHF, AUDUSD, USDCAD

---

## 🔑 Step 1 — Add Your API Keys

Open `src/App.js` and replace lines 10–11:

```js
const FINNHUB_KEY   = "YOUR_FINNHUB_KEY";     // get free at finnhub.io
const ANTHROPIC_KEY = "YOUR_ANTHROPIC_KEY";    // get at console.anthropic.com
```

> ⚠️ Generate a NEW Finnhub key at finnhub.io (the old one was shared in chat).
> Anthropic key format: `sk-ant-api03-...`

---

## 🟢 Option A — Deploy on Replit (Easiest)

1. Go to **replit.com** → Sign up free → click **+ Create Repl**
2. Choose template: **React**
3. Delete all files in the file panel on the left
4. Upload these files keeping the folder structure:
   ```
   package.json
   public/index.html
   src/index.js
   src/App.js
   ```
5. Add your API keys to `src/App.js`
6. Click the green **▶ Run** button
7. Replit gives you a live public URL instantly ✅

---

## 🟣 Option B — Deploy on Lovable (Best quality)

1. Go to **lovable.dev** → Sign up → New project
2. Click the **upload** icon → upload all 4 files
3. Add your API keys when prompted
4. Click **Deploy** → get a shareable URL ✅

---

## ⚡ Option C — Deploy on Bolt.new (Fastest)

1. Go to **bolt.new**
2. Click **Import files** → upload all 4 files
3. Edit `src/App.js` to add your keys
4. Click **Deploy** ✅

---

## 🌐 Option D — GitHub Pages (Free, permanent URL)

1. Go to **github.com** → New repository → name it `alphascan`
2. Upload all 4 files maintaining folder structure
3. In repo Settings → Pages → Source: **GitHub Actions**
4. Add this workflow file as `.github/workflows/deploy.yml`:

```yaml
name: Deploy
on:
  push:
    branches: [main]
jobs:
  build-deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
        with:
          node-version: 18
      - run: npm install
      - run: npm run build
      - uses: peaceiris/actions-gh-pages@v3
        with:
          github_token: ${{ secrets.GITHUB_TOKEN }}
          publish_dir: ./build
```

5. Push → GitHub Actions builds and deploys automatically ✅

---

## 📱 What Works Once Deployed

| Feature | Status |
|---------|--------|
| Crypto prices (BTC/ETH/SOL etc) | ✅ Live 24/7 — Hyperliquid API, free |
| Funding rates | ✅ Live 24/7 — Hyperliquid API, free |
| Stock prices (TSLA/NVDA etc) | ✅ Live NYSE hours — Finnhub free tier |
| Gold & Silver prices | ✅ Live market hours — Finnhub free tier |
| Forex rates | ✅ Live 24/5 — Finnhub free tier |
| AI analyst | ✅ Fully working — Claude API |
| Signals feed | ✅ Auto-rotating, AI-generated |

---

## ⚠️ Important Notes

- **Stocks/metals/forex show "SIM"** outside market hours — this is normal. Finnhub's free tier returns 0 after hours. The last known price is shown.
- **Crypto is always live** — Hyperliquid runs 24/7.
- **Finnhub free tier**: 60 API calls/minute. Dashboard uses ~16 calls per refresh cycle (every 15s) so you're well within limits.
- **Keep your API keys private** — don't share the deployed app's source code publicly with keys in it.

---

## 🆘 Troubleshooting

**"SIM" on everything** → You're still in the Claude.ai sandbox. Deploy to Replit/Lovable/Bolt.

**Finnhub returns 0** → Market is closed (check NYSE hours). This is expected behavior.

**AI not working** → Check your Anthropic key is correct in App.js line 11.

**CORS errors** → Only happens in browser dev tools on localhost. Use `npm start` or deploy to fix.
